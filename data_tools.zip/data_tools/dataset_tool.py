#!/usr/bin/env python3
"""
dataset_tool.py - 모은 데이터를 보고 고쳐서 학습용 dataset(zip)으로 만들기

  - data/ 안의 세션(collect_cv.py · collect_manual.py · cv_lab 녹화)을 모두 보여 줌
  - 사진을 보며 지우기 · 되살리기 · 조향(라벨) 고치기 (여러 장을 한 번에도)
  - 원본(labels.csv · 사진)은 건드리지 않음: 고친 내용은 세션 폴더의 edits.json에만 저장 → 언제든 되돌리기
  - 내보내기: 고른 세션들을 고친 내용대로 묶어 exports/dataset_<날짜_시간>.zip
    → dl_lab Colab 노트북 1번 셀 DATA_OPTION = 'zip'으로 그대로 올리기

실행 (Pi 또는 PC, Flask만 있으면 됨 · 카메라 · 모터 필요 없음):
  python3 dataset_tool.py                 # 이 폴더의 data/
  python3 dataset_tool.py ~/cv_lab/data   # 다른 data 폴더
  브라우저 http://<Pi 또는 PC IP>:8001     (PC에서 실행했다면 http://localhost:8001)

키 (큰 화면):  ← → 이전 · 다음   1 2 3 왼쪽 · 직진 · 오른쪽   Q E 조향 −0.1 · +0.1
               X 또는 Delete 지우기 / 되살리기   U 원래 값   P 자동 넘기기   Esc 닫기
"""
import argparse
import csv
import io
import json
import os
import re
import sys
import threading
import time
import zipfile

PORT = 8001
EDGES = [0.25]                       # 단계 경계 (dl_lab 노트북과 같게): |조향| > 0.25 → 왼쪽 · 오른쪽
KEY_VALUES = {"1": -0.5, "2": 0.0, "3": 0.5}   # 숫자 키로 넣는 조향 (collect_manual의 steer_key와 같음)
EDITS = "edits.json"
HERE = os.path.dirname(os.path.abspath(__file__))
NAME_OK = re.compile(r"^[\w.\-]+$")


def class_means(counts, sums):
    """단계별 평균 조향 = 노트북이 만드는 class_steering (직진은 0으로 고정, 사진이 없는 단계는 None)"""
    mid = len(EDGES)
    return [0.0 if i == mid else (round(sums[i] / counts[i], 3) if counts[i] else None) for i in range(len(counts))]


def steering_class(v):
    """조향 → 단계 번호 (dl_lab 노트북의 steering_to_class와 같음). 3단계: 0 왼쪽, 1 직진, 2 오른쪽"""
    mid = len(EDGES)
    level = sum(abs(v) > e for e in EDGES)
    return mid - level if v < 0 else mid + level


# ---------------------------------------------------------------- 세션 읽기 · 고치기
class Store:
    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.lock = threading.Lock()

    def path(self, name, *parts):
        if not NAME_OK.match(name):
            raise ValueError("잘못된 세션 이름")
        return os.path.join(self.root, name, *parts)

    def sessions(self):
        if not os.path.isdir(self.root):
            return []
        return sorted(d for d in os.listdir(self.root)
                      if NAME_OK.match(d) and os.path.isfile(os.path.join(self.root, d, "labels.csv")))

    def rows(self, name):
        """원본 labels.csv → [{image, steering, ...원본 열}]"""
        with open(self.path(name, "labels.csv"), newline="") as f:
            r = csv.DictReader(f)
            rows = [dict(x) for x in r if x.get("image")]
            return r.fieldnames or [], rows

    def info(self, name):
        p = self.path(name, "info.json")
        if not os.path.exists(p):
            return None
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def edits(self, name):
        p = self.path(name, EDITS)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                e = json.load(f)
        else:
            e = {}
        return {"deleted": set(e.get("deleted", [])), "steering": dict(e.get("steering", {}))}

    def save_edits(self, name, e):
        p = self.path(name, EDITS)
        if not e["deleted"] and not e["steering"]:
            if os.path.exists(p):
                os.remove(p)
            return
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"deleted": sorted(e["deleted"]), "steering": e["steering"],
                       "updated": time.strftime("%Y-%m-%d %H:%M:%S")}, f, ensure_ascii=False, indent=1)
        os.replace(tmp, p)

    def table(self, name):
        """화면용: 원본 + 고친 내용"""
        _, rows = self.rows(name)
        e = self.edits(name)
        out = []
        for i, r in enumerate(rows):
            img = r["image"]
            orig = float(r.get("steering") or 0)
            val = float(e["steering"].get(img, orig))
            out.append({"i": i, "image": img, "orig": orig, "value": val, "cls": steering_class(val),
                        "deleted": img in e["deleted"], "edited": img in e["steering"],
                        "throttle": r.get("throttle", ""),
                        "missing": not os.path.exists(self.path(name, img))})
        return out

    def summary(self, name):
        t = self.table(name)
        kept = [r for r in t if not r["deleted"] and not r["missing"]]
        cls = [0] * (2 * len(EDGES) + 1)
        sums = [0.0] * len(cls)
        for r in kept:
            cls[r["cls"]] += 1
            sums[r["cls"]] += r["value"]
        info = self.info(name)
        return {"name": name, "count": len(t), "kept": len(kept), "deleted": sum(r["deleted"] for r in t),
                "edited": sum(r["edited"] for r in t), "missing": sum(r["missing"] for r in t), "classes": cls,
                "sums": [round(v, 4) for v in sums], "means": class_means(cls, sums),
                "has_info": info is not None,
                "source": (info or {}).get("label_source", ""),
                "tool": ((info or {}).get("collect") or {}).get("tool", "")}

    def edit(self, name, images, action, value=None):
        with self.lock:
            _, rows = self.rows(name)
            valid = {r["image"]: float(r.get("steering") or 0) for r in rows}
            images = [m for m in images if m in valid]
            e = self.edits(name)
            for m in images:
                if action == "delete":
                    e["deleted"].add(m)
                elif action == "restore":
                    e["deleted"].discard(m)
                elif action == "toggle":
                    (e["deleted"].discard if m in e["deleted"] else e["deleted"].add)(m)
                elif action == "set":
                    v = max(-1.0, min(1.0, round(float(value), 3)))
                    if abs(v - valid[m]) < 1e-9:
                        e["steering"].pop(m, None)       # 원래 값과 같으면 고친 것이 아님
                    else:
                        e["steering"][m] = v
                elif action == "add":
                    cur = e["steering"].get(m, valid[m])
                    v = max(-1.0, min(1.0, round(cur + float(value), 3)))
                    if abs(v - valid[m]) < 1e-9:
                        e["steering"].pop(m, None)
                    else:
                        e["steering"][m] = v
                elif action == "reset":
                    e["steering"].pop(m, None)
                    e["deleted"].discard(m)
                else:
                    raise ValueError("알 수 없는 동작: " + str(action))
            self.save_edits(name, e)
            return len(images)

    def export(self, names, out_dir):
        """고른 세션들을 고친 내용대로 zip으로. zip 안: data/<세션>/images/*.jpg, labels.csv, info.json"""
        os.makedirs(out_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        zpath = os.path.join(out_dir, f"dataset_{stamp}.zip")
        report = []
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:   # jpg는 이미 압축됨 → 그냥 담기 (빠름)
            for name in names:
                fields, rows = self.rows(name)
                e = self.edits(name)
                fields = fields or ["image", "steering", "throttle", "time"]
                buf = io.StringIO()
                w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
                w.writeheader()
                n = 0
                cls = [0] * (2 * len(EDGES) + 1)
                sums = [0.0] * len(cls)
                for r in rows:
                    img = r["image"]
                    src = self.path(name, img)
                    if img in e["deleted"] or not os.path.exists(src):
                        continue
                    r = dict(r)
                    if img in e["steering"]:
                        r["steering"] = f"{e['steering'][img]:.3f}"
                    w.writerow(r)
                    z.write(src, f"data/{name}/{img}")
                    v = float(r["steering"])
                    cls[steering_class(v)] += 1
                    sums[steering_class(v)] += v
                    n += 1
                if n == 0:
                    continue
                z.writestr(f"data/{name}/labels.csv", buf.getvalue())
                info = self.info(name)
                if info is not None:
                    info = dict(info)
                    info["dataset_tool"] = {"exported": stamp, "kept": n, "original": len(rows),
                                            "deleted": len(e["deleted"]), "edited": len(e["steering"])}
                    z.writestr(f"data/{name}/info.json", json.dumps(info, ensure_ascii=False, indent=2))
                report.append({"name": name, "kept": n, "classes": cls, "sums": sums, "has_info": info is not None})
        if not report:
            os.remove(zpath)
            return None, report
        return zpath, report


# ---------------------------------------------------------------- 웹
def create_app(data_root, export_dir=None):
    from flask import Flask, abort, jsonify, request, send_file
    store = Store(data_root)
    export_dir = os.path.abspath(export_dir or os.path.join(HERE, "exports"))
    app = Flask(__name__)
    app.config["store"] = store

    @app.route("/")
    def index():
        return PAGE.replace("__CFG__", json.dumps({"edges": EDGES, "keys": KEY_VALUES, "root": store.root,
                                                   "exports": export_dir}))

    @app.route("/api/sessions")
    def sessions():
        out = []
        for n in store.sessions():
            try:
                out.append(store.summary(n))
            except Exception as ex:
                out.append({"name": n, "error": str(ex)})
        return jsonify(out)

    @app.route("/api/session/<name>")
    def session(name):
        try:
            return jsonify({"rows": store.table(name), "info": store.info(name), "summary": store.summary(name)})
        except (ValueError, FileNotFoundError):
            abort(404)

    @app.route("/img/<name>/<path:image>")
    def image(name, image):
        try:
            p = os.path.realpath(store.path(name, image))
        except ValueError:
            abort(404)
        if (not p.startswith(os.path.realpath(store.path(name)) + os.sep) or not os.path.isfile(p)
                or not p.lower().endswith((".jpg", ".jpeg", ".png"))):
            abort(404)
        return send_file(p, max_age=3600)

    @app.route("/api/session/<name>/edit", methods=["POST"])
    def edit(name):
        d = request.get_json(silent=True) or {}
        try:
            n = store.edit(name, d.get("images") or [], d.get("action"), d.get("value"))
        except (ValueError, TypeError, FileNotFoundError) as ex:
            return jsonify({"error": str(ex)}), 400
        return jsonify({"changed": n, "summary": store.summary(name)})

    @app.route("/api/export", methods=["POST"])
    def export():
        d = request.get_json(silent=True) or {}
        names = [n for n in (d.get("sessions") or []) if n in store.sessions()]
        if not names:
            return jsonify({"error": "세션을 하나 이상 고르세요"}), 400
        path, report = store.export(names, export_dir)
        if not path:
            return jsonify({"error": "남은 사진이 없습니다"}), 400
        tc = [sum(r["classes"][i] for r in report) for i in range(len(report[0]["classes"]))]
        ts = [sum(r["sums"][i] for r in report) for i in range(len(tc))]
        return jsonify({"file": os.path.basename(path), "path": path, "report": report,
                        "classes": tc, "means": class_means(tc, ts),
                        "mb": round(os.path.getsize(path) / 1e6, 1)})

    @app.route("/exports/<fname>")
    def download(fname):
        if not NAME_OK.match(fname) or not fname.endswith(".zip"):
            abort(404)
        p = os.path.join(export_dir, fname)
        if not os.path.isfile(p):
            abort(404)
        return send_file(p, as_attachment=True, download_name=fname)

    return app


def main():
    ap = argparse.ArgumentParser(description="모은 데이터를 보고 고쳐서 dataset zip 만들기")
    ap.add_argument("data", nargs="?", default=os.path.join(HERE, "data"), help="세션 폴더들이 있는 data 폴더")
    ap.add_argument("--port", type=int, default=PORT)
    args = ap.parse_args()
    root = os.path.expanduser(args.data)
    if os.path.exists(root) and not os.path.isdir(root):
        sys.exit(f"폴더가 아니라 파일임: {root}")
    if not os.path.isdir(root):
        os.makedirs(root)
        print(f"data 폴더가 없어서 새로 만듦: {os.path.abspath(root)}")
    app = create_app(root)
    n = len(app.config["store"].sessions())
    if n == 0:
        print("  아직 세션이 없음: collect_cv.py · collect_manual.py로 모으거나, 세션 폴더(labels.csv + images/)를 여기에 복사한 뒤 브라우저 새로고침")
    print(f"data: {os.path.abspath(root)} (세션 {n}개)  →  http://<IP>:{args.port}  (이 컴퓨터라면 http://localhost:{args.port})")
    app.run(host="0.0.0.0", port=args.port, threaded=True)


PAGE = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>dataset_tool</title>
<style>
 :root{--bg:#121417;--panel:#1c1f24;--line:#30353c;--text:#e8eaed;--dim:#9aa0a6;--l:#4285f4;--s:#9aa0a6;--r:#f29900;--del:#d93025;--ok:#1e8e3e}
 *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--text);font:14px/1.4 sans-serif}
 header{padding:10px 14px;border-bottom:1px solid var(--line);display:flex;gap:12px;align-items:center;flex-wrap:wrap}
 header h1{font-size:17px;margin:0} .dim{color:var(--dim)}
 main{display:grid;grid-template-columns:290px 1fr;min-height:calc(100vh - 50px)}
 aside{border-right:1px solid var(--line);padding:10px;overflow:auto;max-height:calc(100vh - 50px)}
 @media(max-width:800px){main{grid-template-columns:1fr} aside{max-height:none;border-right:0;border-bottom:1px solid var(--line)}}
 .ses{padding:8px;border-radius:8px;margin-bottom:6px;background:var(--panel);cursor:pointer;border:1px solid transparent}
 .ses.cur{border-color:var(--l)} .ses .t{display:flex;gap:6px;align-items:center;font-weight:600;word-break:break-all}
 .ses small{display:block;color:var(--dim)} .warn{color:#f6ad55}
 .bar{display:flex;height:8px;border-radius:4px;overflow:hidden;margin-top:5px;background:#333}
 .bar i{display:block;height:100%}
 button,select,input[type=number]{background:#2d3238;color:var(--text);border:1px solid var(--line);border-radius:6px;padding:6px 10px;font-size:14px}
 button{cursor:pointer} button:hover{border-color:#5f6368} button.pri{background:var(--l);border-color:var(--l)} button.red{background:var(--del);border-color:var(--del)}
 section{padding:10px 14px}
 .tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
 .card{position:relative;background:var(--panel);border-radius:6px;overflow:hidden;border:2px solid transparent;cursor:pointer}
 .card.sel{border-color:#fbbc04} .card img{width:100%;display:block;aspect-ratio:4/3;object-fit:cover}
 .card.del img{opacity:.25} .card .x{position:absolute;top:4px;right:6px;color:var(--del);font-weight:700;font-size:18px;display:none} .card.del .x{display:block}
 .card .m{display:flex;justify-content:space-between;padding:3px 6px;font:12px monospace}
 .card .ed{color:#fbbc04} .sv{position:absolute;left:0;top:0;width:100%;pointer-events:none}
 .c0{color:var(--l)} .c1{color:var(--s)} .c2{color:var(--r)}
 .pager{display:flex;gap:6px;align-items:center;margin:10px 0}
 #viewer{position:fixed;inset:0;background:rgba(0,0,0,.92);display:none;align-items:center;justify-content:center;flex-direction:column;z-index:5}
 #viewer .box{position:relative;width:min(92vw,760px)} #viewer img{width:100%;display:block;border-radius:6px}
 #viewer .vinfo{font:15px monospace;margin:10px;text-align:center} #viewer .del{color:var(--del);font-weight:700}
 #viewer .vbtn{display:flex;gap:6px;flex-wrap:wrap;justify-content:center}
 .hist{display:flex;align-items:flex-end;gap:1px;height:60px;margin:6px 0 2px}
 .hist i{flex:1;background:#5f6368;min-height:1px}
 #msg{position:fixed;bottom:14px;left:50%;transform:translateX(-50%);background:#323639;padding:8px 14px;border-radius:8px;display:none;z-index:9;max-width:90vw}
 a{color:#8ab4f8}
</style></head><body>
<header><h1>dataset_tool</h1><span class="dim" id="root"></span></header>
<main>
<aside>
 <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><b>세션</b>
  <label class="dim"><input type="checkbox" id="all"> 모두 고르기</label></div>
 <div id="sessions"></div>
 <div style="margin-top:10px;padding:8px;background:var(--panel);border-radius:8px">
  <b>내보내기</b> <span class="dim">(체크한 세션)</span>
  <div id="expsum" class="dim" style="margin:6px 0">-</div>
  <div class="bar" id="expbar"></div>
  <button class="pri" id="export" style="margin-top:8px;width:100%">dataset zip 만들기</button>
  <div id="expres" style="margin-top:6px;word-break:break-all"></div>
 </div>
 <p class="dim" style="font-size:12px">원본은 그대로 두고 고친 내용만 세션 폴더의 edits.json에 저장합니다.<br>단계 색: <span class="c0">왼쪽</span> · <span class="c1">직진</span> · <span class="c2">오른쪽</span> (경계 <span id="edges"></span>)<br>
 단계별 조향값 = 그 단계 사진들의 조향 평균 (노트북은 학습용 80%로 계산하므로 조금 다를 수 있음) → Pi가 실제로 꺾는 값</p>
</aside>
<section>
 <div id="head" class="dim">왼쪽에서 세션을 고르세요</div>
 <div class="hist" id="hist" title="조향 분포 (−1 → +1)"></div>
 <div class="tools" id="tools" style="display:none">
  <select id="filter"><option value="all">전체</option><option value="kept">남은 것</option><option value="del">지운 것</option>
   <option value="edited">고친 것</option><option value="0">왼쪽</option><option value="1">직진</option><option value="2">오른쪽</option></select>
  <span class="dim" id="selinfo">선택 0장</span>
  <button id="bdel" class="red">지우기</button><button id="bres">되살리기</button>
  <input type="number" id="setv" step="0.05" min="-1" max="1" value="0" style="width:80px"><button id="bset">조향 넣기</button>
  <button id="breset">원래대로</button><button id="bnone">선택 해제</button>
 </div>
 <div class="pager" id="pager"></div>
 <div class="grid" id="grid"></div>
 <p class="dim" style="font-size:12px">클릭 = 선택 · Shift+클릭 = 범위 선택 · 더블클릭 = 크게 보기 (키보드로 빠르게 고치기)</p>
</section>
</main>
<div id="viewer"><div class="box"><img id="vimg"><svg class="sv" id="vsvg" viewBox="0 0 320 240"></svg></div>
 <div class="vinfo" id="vinfo"></div>
 <div class="vbtn">
  <button data-a="prev">◀ 이전</button><button data-a="k1">1 왼쪽</button><button data-a="k2">2 직진</button><button data-a="k3">3 오른쪽</button>
  <button data-a="m">Q −0.1</button><button data-a="p">E +0.1</button><button data-a="x" class="red">X 지우기</button><button data-a="u">U 원래 값</button>
  <button data-a="play">P 자동</button><button data-a="next">다음 ▶</button><button data-a="close">Esc 닫기</button></div>
 <div class="dim" style="margin-top:8px;font-size:12px">초록 화살표 = 지금 라벨 · 회색 = 원래 값</div>
</div>
<div id="msg"></div>
<script>
const CFG = __CFG__, PAGE = 120;
const $ = id => document.getElementById(id);
let sessions = [], cur = null, rows = [], view = [], page = 0, sel = new Set(), last = null, vi = -1, timer = null;
const checked = new Set(JSON.parse(localStorageGet('checked') || '[]'));
function localStorageGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function localStorageSet(k,v){try{localStorage.setItem(k,v)}catch(e){}}
$('root').textContent = CFG.root; $('edges').textContent = '±' + CFG.edges.join(', ±');
const CLS = ['c0','c1','c2','c3','c4'], NAMES = CFG.edges.length===1 ? ['왼쪽','직진','오른쪽'] : ['크게 왼쪽','왼쪽','직진','오른쪽','크게 오른쪽'];
const COLORS = CFG.edges.length===1 ? ['#4285f4','#9aa0a6','#f29900'] : ['#1a56c4','#4285f4','#9aa0a6','#f29900','#c26401'];
function msg(t, ms=2500){const m=$('msg'); m.textContent=t; m.style.display='block'; clearTimeout(msg.t); msg.t=setTimeout(()=>m.style.display='none', ms);}
async function api(url, body){const r = await fetch(url, body ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)} : {});
  const j = await r.json(); if(!r.ok) throw new Error(j.error || r.status); return j;}
function bar(cls){const n = cls.reduce((a,b)=>a+b,0)||1; return cls.map((c,i)=>`<i style="width:${100*c/n}%;background:${COLORS[i]}" title="${NAMES[i]} ${c}"></i>`).join('');}
function clsText(cls){return cls.map((c,i)=>`<span class="${CLS[i]}">${NAMES[i]} ${c}</span>`).join(' · ');}
const MID = CFG.edges.length, FALLBACK = CFG.edges.length===1 ? [-0.5, 0, 0.5] : null;
function means(cls, sums){return cls.map((c,i)=> i===MID ? 0 : (c ? sums[i]/c : null));}
function fmt(v){return (v>=0?'+':'−') + Math.abs(v).toFixed(2);}
function meansText(m){return '단계별 조향값 (class_steering) ≈ ' + m.map((v,i)=>`<span class="${CLS[i]}">${NAMES[i]} ${
   i===MID ? '0 (고정)' : v===null ? `<span class="warn">사진 없음${FALLBACK?` → 기본 ${fmt(FALLBACK[i])}`:''}</span>` : '<b>'+fmt(v)+'</b>'}</span>`).join(' · ');}

async function loadSessions(){
  sessions = await api('/api/sessions');
  $('sessions').innerHTML = sessions.length ? sessions.map(s => s.error ? `<div class="ses">${s.name}<small class="warn">${s.error}</small></div>` :
   `<div class="ses ${cur===s.name?'cur':''}" data-n="${s.name}"><div class="t"><input type="checkbox" ${checked.has(s.name)?'checked':''} data-c="${s.name}">${s.name}</div>
    <small>${s.kept} / ${s.count}장 · 지움 ${s.deleted} · 고침 ${s.edited}${s.missing?` · <span class="warn">사진 없음 ${s.missing}</span>`:''} · ${s.source||'?'}</small>
    ${s.has_info?'':'<small class="warn">info.json 없음 → 노트북이 사진을 180도 돌려서 학습</small>'}
    <div class="bar">${bar(s.classes)}</div></div>`).join('') : '<p class="dim">세션이 없습니다. collect_cv.py · collect_manual.py로 모으거나, 세션 폴더(labels.csv + images/)를 위 data 폴더에 복사한 뒤 새로고침(F5)하세요.</p>';
  document.querySelectorAll('.ses[data-n]').forEach(d => d.onclick = e => { if(e.target.dataset.c) return; open(d.dataset.n); });
  document.querySelectorAll('[data-c]').forEach(c => c.onchange = () => { c.checked ? checked.add(c.dataset.c) : checked.delete(c.dataset.c); saveChecked(); expSummary(); });
  $('all').checked = sessions.length && sessions.every(s => checked.has(s.name));
  expSummary();
}
function saveChecked(){localStorageSet('checked', JSON.stringify([...checked]));}
$('all').onchange = () => { sessions.forEach(s => $('all').checked ? checked.add(s.name) : checked.delete(s.name)); saveChecked(); loadSessions(); };
function expSummary(){
  const ss = sessions.filter(s => checked.has(s.name) && !s.error);
  const cls = ss.reduce((a,s)=>a.map((v,i)=>v+s.classes[i]), NAMES.map(()=>0)); const n = cls.reduce((a,b)=>a+b,0);
  const sums = ss.reduce((a,s)=>a.map((v,i)=>v+(s.sums?s.sums[i]:0)), NAMES.map(()=>0));
  $('expsum').innerHTML = ss.length ? `${ss.length}개 세션 · ${n}장<br>${clsText(cls)}<br>${meansText(means(cls, sums))}` : '세션을 체크하세요';
  $('expbar').innerHTML = ss.length ? bar(cls) : '';
}
$('export').onclick = async () => {
  const names = sessions.filter(s => checked.has(s.name)).map(s => s.name);
  $('expres').innerHTML = '만드는 중...';
  try { const r = await api('/api/export', {sessions: names});
    $('expres').innerHTML = `<a href="/exports/${r.file}" download>${r.file}</a> (${r.mb} MB) 내려받기<br>${meansText(r.means.map(v=>v))}<br><span class="dim" style="font-size:12px">${r.path}<br>${r.report.map(x=>`${x.name}: ${x.kept}장${x.has_info?'':' (info.json 없음)'}`).join('<br>')}</span>`;
  } catch(e){ $('expres').innerHTML = `<span class="warn">${e.message}</span>`; }
};

async function open(name, keep){
  const d = await api('/api/session/' + name); cur = name; rows = d.rows;
  if(!keep){ sel.clear(); page = 0; last = null; }
  const s = d.summary, info = d.info || {};
  $('head').innerHTML = `<b style="color:var(--text)">${name}</b> · <span id="hstat"></span>
    <br>${info.collect ? `수집: ${info.collect.tool||''}${info.collect.bands?` 띠 ${info.collect.bands}개`:''} · 라벨 ${info.label_source||''}` : (d.info===null?'<span class="warn">info.json 없음</span>':'')}`;
  $('tools').style.display = 'flex'; hist(); headStat(); applyFilter(); loadSessions();
}
function headStat(){  // 지금 세션을 이대로 내보내면: 장수 · 단계 · 단계별 평균 조향
  const kept = rows.filter(r => !r.deleted && !r.missing), cls = NAMES.map(()=>0), sums = NAMES.map(()=>0);
  kept.forEach(r => { cls[r.cls]++; sums[r.cls] += r.value; });
  $('hstat').innerHTML = `${kept.length} / ${rows.length}장 남김 · 지움 ${rows.filter(r=>r.deleted).length} · 고침 ${rows.filter(r=>r.edited).length} · ${clsText(cls)}<br>${meansText(means(cls, sums))}`;
}
function hist(){const b = new Array(41).fill(0); rows.filter(r=>!r.deleted).forEach(r => b[Math.round((r.value+1)*20)]++);
  const m = Math.max(1,...b); $('hist').innerHTML = b.map((c,i)=>`<i style="height:${100*c/m}%;background:${COLORS[clsOf(i/20-1)]}" title="${(i/20-1).toFixed(2)}: ${c}장"></i>`).join('');}
function clsOf(v){const lv = CFG.edges.filter(e=>Math.abs(v)>e).length, mid = CFG.edges.length; return v<0 ? mid-lv : mid+lv;}
function applyFilter(){const f = $('filter').value;
  view = rows.filter(r => f==='all' || (f==='kept'&&!r.deleted) || (f==='del'&&r.deleted) || (f==='edited'&&r.edited) || (String(r.cls)===f && !r.deleted));
  page = Math.min(page, Math.max(0, Math.ceil(view.length/PAGE)-1)); render();}
$('filter').onchange = () => { page = 0; applyFilter(); };
function arrow(v, color, w){const x = 160 + v*128; return `<line x1="160" y1="232" x2="${x}" y2="132" stroke="${color}" stroke-width="${w}" stroke-linecap="round"/><circle cx="${x}" cy="132" r="${w*1.4}" fill="${color}"/>`;}
function render(){
  const pages = Math.max(1, Math.ceil(view.length/PAGE)), part = view.slice(page*PAGE, page*PAGE+PAGE);
  $('pager').innerHTML = `<button ${page?'':'disabled'} id="pp">◀</button><span>${page+1} / ${pages} 쪽 · ${view.length}장</span><button ${page<pages-1?'':'disabled'} id="pn">▶</button>
    <button id="selpage">이 쪽 모두 선택</button>`;
  $('pp').onclick = () => { page--; render(); }; $('pn').onclick = () => { page++; render(); };
  $('selpage').onclick = () => { part.forEach(r => sel.add(r.i)); markSel(); };
  $('grid').innerHTML = part.map(r => `<div class="card ${r.deleted?'del':''} ${sel.has(r.i)?'sel':''}" data-i="${r.i}">
     <img loading="lazy" src="/img/${cur}/${r.image}"><svg class="sv" viewBox="0 0 320 240">${arrow(r.value, r.deleted?'#777':COLORS[r.cls], 7)}</svg><span class="x">✕</span>
     <div class="m"><span>#${r.i+1}</span><span class="${CLS[r.cls]} ${r.edited?'ed':''}">${r.value>=0?'+':''}${r.value.toFixed(2)}${r.edited?' *':''}</span></div></div>`).join('');
  document.querySelectorAll('.card').forEach(c => {
    const i = +c.dataset.i;
    c.onclick = e => { if(e.shiftKey && last!==null){ const a = view.findIndex(r=>r.i===last), b = view.findIndex(r=>r.i===i);
        view.slice(Math.min(a,b), Math.max(a,b)+1).forEach(r => sel.add(r.i)); }
      else if(sel.has(i)) sel.delete(i); else sel.add(i); last = i; markSel(); };
    c.ondblclick = () => openViewer(view.findIndex(r => r.i === i));
  });
  $('selinfo').textContent = `선택 ${sel.size}장`;
}
function markSel(){ document.querySelectorAll('.card').forEach(c => c.classList.toggle('sel', sel.has(+c.dataset.i))); $('selinfo').textContent = `선택 ${sel.size}장`; }
async function edit(images, action, value){
  if(!images.length){ msg('먼저 사진을 고르세요'); return; }
  await api(`/api/session/${cur}/edit`, {images, action, value});
  const d = await api('/api/session/' + cur); rows = d.rows; hist(); headStat();
  const f = $('filter').value; if(f!=='all') { /* 필터가 바뀌어도 화면이 갑자기 바뀌지 않게 지금 목록 유지 */ view = view.map(v => rows[v.i]); render(); } else applyFilter();
  loadSessions();
}
const selImages = () => [...sel].map(i => rows[i].image);
async function bulk(action, value){ const imgs = selImages(); await edit(imgs, action, value); if(imgs.length){ msg(`${imgs.length}장 처리`); sel.clear(); markSel(); } }
$('bdel').onclick = () => bulk('delete');
$('bres').onclick = () => bulk('restore');
$('bset').onclick = () => bulk('set', Number($('setv').value));
$('breset').onclick = () => { if(sel.size && confirm(`${sel.size}장을 원래대로 (지움 · 고침 모두 취소)?`)) bulk('reset'); };
$('bnone').onclick = () => { sel.clear(); markSel(); };

function openViewer(k){ if(k<0) return; vi = k; $('viewer').style.display = 'flex'; showV(); }
function showV(){ const r = view[vi]; if(!r) return;
  $('vimg').src = `/img/${cur}/${r.image}`;
  $('vsvg').innerHTML = (r.edited ? arrow(r.orig, '#bbb', 4) : '') + arrow(r.value, r.deleted ? '#777' : '#34a853', 7);
  $('vinfo').innerHTML = `${vi+1} / ${view.length} · ${r.image} · 조향 <b class="${CLS[r.cls]}">${r.value>=0?'+':''}${r.value.toFixed(2)} ${NAMES[r.cls]}</b>`
    + (r.edited ? ` (원래 ${r.orig.toFixed(2)})` : '') + (r.deleted ? ' · <span class="del">지움</span>' : '') + (timer ? ' · 자동 넘기기' : '');
}
function closeV(){ $('viewer').style.display = 'none'; vi = -1; stopPlay(); render(); }
function stopPlay(){ clearInterval(timer); timer = null; }
async function vact(a){
  const r = view[vi]; if(!r) return;
  if(a==='prev'){ vi = Math.max(0, vi-1); return showV(); }
  if(a==='next'){ vi = Math.min(view.length-1, vi+1); return showV(); }
  if(a==='close') return closeV();
  if(a==='play'){ if(timer) stopPlay(); else timer = setInterval(() => { if(vi >= view.length-1) stopPlay(); else vi++; showV(); }, 100); return showV(); }
  if(a[0]==='k') await edit([r.image], 'set', CFG.keys[a[1]]);
  if(a==='m') await edit([r.image], 'add', -0.1);
  if(a==='p') await edit([r.image], 'add', 0.1);
  if(a==='x') await edit([r.image], 'toggle');
  if(a==='u') await edit([r.image], 'reset');
  showV();
}
document.querySelectorAll('#viewer [data-a]').forEach(b => b.onclick = () => vact(b.dataset.a));
document.addEventListener('keydown', e => {
  if(vi < 0 || e.target.tagName === 'INPUT') return;
  const k = e.key, map = {ArrowLeft:'prev', ArrowRight:'next', Escape:'close', '1':'k1', '2':'k2', '3':'k3', q:'m', Q:'m', e:'p', E:'p', x:'x', X:'x', Delete:'x', u:'u', U:'u', p:'play', P:'play'};
  if(map[k]){ e.preventDefault(); vact(map[k]); }
});
loadSessions();
</script></body></html>"""


if __name__ == "__main__":
    main()
