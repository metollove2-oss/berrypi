data_tools v0 - 학습 데이터 모으기 · 정리 도구 (cv_lab · dl_lab 다음 단계)

합성 데이터로 학습한 모델은 실제 트랙에서 잘 달리지 못합니다 (바닥 · 조명 · 카메라가 다름).
우리 트랙에서 직접 사진을 모아 학습해야 합니다. 이 폴더의 도구 세 개로 모으고 → 정리하고 → 노트북에 올립니다.

파일
  collect_cv.py       [Pi] OpenCV로 선을 따라 달리며 모으기 (라벨 = OpenCV 조향). 띠 1개 / 3개 선택
  collect_manual.py   [Pi] 키보드 · 화면 버튼으로 직접 운전하며 모으기 (라벨 = 내가 누른 조향)
  dataset_tool.py     [Pi 또는 PC] 모은 사진을 보며 지우기 · 라벨 고치기 → dataset zip 만들기
  common.py           두 수집 도구가 같이 쓰는 카메라 · 모터 · 저장 부품
  arduino/motor_serial/motor_serial.ino   아두이노 코드 (cv_lab과 같음)

준비 (Pi 5, 한 번만) - cv_lab에서 이미 했다면 이 폴더에 venv만 새로 만들기
  sudo apt install -y python3-venv python3-picamera2 python3-opencv python3-numpy python3-flask python3-serial
  cd ~/codes/data_tools
  python3 -m venv --system-site-packages venv
  source venv/bin/activate
  PC에서 dataset_tool.py만 쓸 때:  pip install flask

1) OpenCV로 달리며 모으기
  python3 collect_cv.py              # 띠 3개 (기본)
  python3 collect_cv.py --bands 1    # 띠 1개 (cv_lab과 같은 방식)
  브라우저 http://<Pi IP>:8000
  - 바퀴를 띄우고 thresh · roi_top · look을 맞춤 (오른쪽 mask에 선만 하얗게, 띠에 빨간 점)
  - 트랙에서 '출발 (Space)' → 잘 달리면 '녹화 (R)'. 선을 본 장면만 1초에 10장
  - 띠 1개: 띠 하나(look)만 봄. 간단하지만 커브에서 띠가 선을 놓치기 쉬움
    띠 3개: look · 중간 · 아래(0.92) 세 띠를 0.5 · 0.3 · 0.2 비중으로 섞음. 커브를 미리 보고, 한 띠를 놓쳐도 계속 감
    두 방식 모두 띠 안에 선 후보가 여러 개면(평행선 · 잡티, 주황 띠) 지난번 선에 가장 가까운 것을 고름
  - noise (잡음 주입, 처음 0): 주행 조향에만 잡음을 더하고(보라 화살표), 라벨은 잡음 없는 OpenCV 조향(초록)으로 저장
    → 차가 선에서 조금 벗어난 사진 + 복귀 조향이 모여, 모델이 이탈 후 복귀하는 법을 배움
    힌트 (꼭 따르지 않아도 됨):
      · 벗어난 사진에서도 OpenCV 라벨이 맞아야 의미가 있음 → noise 0으로 몇 바퀴 안정적으로 도는지 먼저 확인
      · 바퀴를 띄우고 차를 손으로 좌우로 조금 옮겨 봐도 빨간 점이 맞는 선에 찍히는지
      · 0.1부터 조금씩. LOST · 주황 띠(후보 여러 개)가 늘면 낮추기. 평행선 · 그림자 구간이 많으면 0
      · 한 바퀴는 noise 0, 다음 바퀴는 noise를 켜서 섞기
      · OpenCV가 불안한 구간의 복귀 장면은 collect_manual로 보충 (벗어날 때 녹화 끄고, 돌아올 때만 녹화)
    잡음으로 모은 사진은 dataset_tool에서 '운전 실수'로 지우지 않기 (라벨은 복귀 방향이라 맞음).
    단, 너무 벗어나 엉뚱한 선을 따라간 사진은 지우거나 고치기
  - 라벨은 OpenCV 조향이라 OpenCV가 실수하면 라벨도 틀림 → dataset_tool.py로 확인

2) 직접 운전하며 모으기
  python3 collect_manual.py          → 브라우저 http://<Pi IP>:8000 (키보드 있는 PC 브라우저 권장)
  - ↑ W 앞으로 · ↓ S 뒤로 · ← → A D 조향 ±steer_key (Shift와 함께 ±1.0) · 누르고 있는 동안만 움직임
  - Space 녹화. 앞으로 가는 동안만 1초에 10장 (멈춤 · 뒤로는 저장 안 함)
  - 휴대폰: 화면의 ▲ ◀ ▶ ▼ 버튼을 누르고 있기
  - smooth (초, 처음 0): 조향이 천천히 바뀜 → 덜 덜컥이고 라벨에 중간 값(조금 꺾음)도 생김
  - 라벨이 내 운전 실력: 늦게 꺾은 장면 · 실수한 장면은 dataset_tool.py에서 지우거나 고치기
  - 일부러 선에서 조금 벗어나기(녹화 끄고) → 돌아오기(녹화 켜고)를 섞으면 모델이 돌아오는 법을 배움

  저장 위치 (두 도구 같음): data/<날짜_시간>_cv1 · _cv3 · _manual/
    images/000001.jpg ...   카메라 사진 (320 × 240, 이미 바로 선 사진)
    labels.csv              image, steering, throttle, time
    info.json               수집 방법 · 설정 (이 파일이 있어야 노트북이 사진을 돌리지 않음)
  녹화를 끄고 다시 켜면 새 폴더(세션)가 생김 → 잘못 달린 세션은 통째로 빼기 쉬움

3) 정리하고 dataset 만들기
  python3 dataset_tool.py                  # 이 폴더의 data/
  python3 dataset_tool.py ~/codes/cv_lab/data   # cv_lab에서 녹화한 데이터도 됨
  브라우저 http://<Pi IP>:8001  (PC에서 실행했다면 http://localhost:8001)
  - 왼쪽: 세션 목록 (남은 장수 · 지운 장수 · 고친 장수 · 왼쪽 / 직진 / 오른쪽 비율 막대)
  - 가운데: 사진 + 라벨 화살표 (파랑 왼쪽 · 회색 직진 · 주황 오른쪽, 경계 ±0.25 = dl_lab 노트북과 같음)
    클릭 = 선택, Shift + 클릭 = 범위 선택 → 지우기 · 되살리기 · 조향 넣기 · 원래대로
    필터: 남은 것 · 지운 것 · 고친 것 · 단계별
  - 더블클릭 = 크게 보기 (키보드로 빠르게):
    ← → 이전 · 다음   1 2 3 왼쪽(−0.5) · 직진(0) · 오른쪽(+0.5)   Q E −0.1 · +0.1
    X / Delete 지우기 · 되살리기   U 원래 값   P 자동 넘기기 (1초에 10장)   Esc 닫기
  - 원본(labels.csv, 사진)은 그대로. 고친 내용은 세션 폴더의 edits.json에만 → 언제든 되돌리기
  - 단계별 조향값(class_steering) 미리 보기: 세션 위쪽 · 내보내기 칸에 '이대로 학습하면 Pi가 꺾을 값'
    = 그 단계 사진들의 조향 평균 (직진은 0). 고칠 때마다 바로 바뀜. 노트북은 학습용 80%로 계산하므로 조금 다를 수 있음
    1 2 3 키(±0.5)로 많이 고치면 평균이 ±0.5 쪽으로 → 커브에서 덜 꺾을 수 있음 (Q E · 숫자 칸으로 크기 맞추기)
  - 내보내기: 세션 체크 → 'dataset zip 만들기' → exports/dataset_<날짜_시간>.zip (화면의 링크로 내려받기)
    zip 안: data/<세션>/images, labels.csv(지운 사진 빼고, 고친 라벨 반영), info.json

4) 학습 (dl_lab Colab 노트북)
  1번 셀: DATA_OPTION = 'zip', ZIP_FROM = 'upload' (또는 Drive에 올리고 'drive')
  합성 데이터를 이미 만들었다면  !rm -rf /content/data/synth_*  후 1번 셀부터 다시 (진짜 데이터만으로 학습)

무엇을 지우고 고칠까
  - 선이 화면에 없거나 반쯤 잘린 사진, 흔들려 흐린 사진, 손 · 발이 찍힌 사진 → 지우기
  - 라벨 방향이 사진과 반대 (선은 오른쪽으로 휘는데 왼쪽 화살표) → 고치기
  - 출발 직후 · 멈추기 직전 몇 장 → 지우기
  - 직진만 너무 많으면: 필터 '직진' → 비슷한 사진 일부 지우기 (노트북이 단계별 가중치로 어느 정도 맞춰 주지만 너무 치우치면 좋지 않음)
  - 각 단계(왼쪽 · 직진 · 오른쪽)가 적어도 수백 장씩 되게 모으기. 모두 합쳐 1,500 ~ 3,000장이면 시작하기 좋음
  - 트랙을 양쪽 방향(시계 · 반시계)으로 모두 달려 모으기 (노트북의 좌우 반전도 도움이 되지만 실제 사진이 더 좋음)

잘 안 될 때
  - "아두이노를 찾을 수 없음": USB 연결, ls /dev/ttyACM*
  - 화면이 거꾸로: common.py의 ROTATE_180
  - 계속 LOST: thresh · roi_top 조정 (mask에 선이 하얗게 보이게)
  - 포트 8000이 이미 사용 중: 다른 수집 도구 · cv_lab · dl_lab이 켜져 있는지 확인 (Ctrl + C로 끄기)
  - dataset_tool에 'info.json 없음': 예전 방식 데이터. 노트북이 180도 돌려서 학습하므로, 사진이 이미 바로 서 있다면
    그 세션 폴더에 info.json을 만들어 넣기 (다른 세션의 info.json을 복사해도 됨)
