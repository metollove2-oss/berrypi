#!/usr/bin/env python3
"""
collect_cv.py - OpenCV로 선을 따라 달리며 학습 데이터 모으기 (라벨 = OpenCV가 계산한 조향)

  띠 1개 (--bands 1): cv_lab과 같은 방식. 띠 하나(look)에서 선 위치 → PD 조향
  띠 3개 (--bands 3): 먼 띠(look) · 중간 · 가까운 띠(0.92)를 함께 봄 (비중 0.5 · 0.3 · 0.2)
                     커브를 미리 보고, 한 띠에서 선을 놓쳐도 나머지로 계속 감
  두 방식 모두: 띠 안에 선 후보가 여러 개면(평행선 · 잡티) 지난번 선에 가장 가까운 것을 고름

  잡음 주입 (noise 슬라이더, 처음 0): 주행 조향에만 잡음을 더해 차가 선에서 조금씩 벗어나게 하고,
    라벨은 잡음 없는 OpenCV 조향으로 저장 → 모델이 이탈 후 복귀하는 법을 배움.
    힌트: 벗어난 사진에서도 OpenCV 라벨이 맞아야 의미가 있음. noise 0으로 안정적으로 도는 것을 먼저 확인하고,
    0.1부터 조금씩 (평행선 · 그림자 구간이 많으면 낮게 또는 0).
    OpenCV가 늘 가운데로만 달리면 모델은 벗어난 장면을 본 적이 없어서, 조금만 벗어나도 못 돌아옴.

실행 (Pi 5, 카메라 + 아두이노 USB + 모터 배터리):
  source venv/bin/activate
  python3 collect_cv.py              # 띠 3개 (기본)
  python3 collect_cv.py --bands 1    # 띠 1개 (cv_lab과 같음)
  브라우저 http://<Pi IP>:8000 → 바퀴를 띄우고 thresh · roi_top · look 맞추기 → 트랙에서 '출발' → '녹화'

저장: data/<날짜_시간>_cv1 또는 _cv3/ (images/, labels.csv, info.json) → dataset_tool.py로 확인 · 정리
"""
import argparse
import json
import random
import threading
import time

import cv2
import numpy as np

import common

PORT = 8000
SETTINGS = {               # 웹 화면 슬라이더로 바꾸는 값 (처음 값)
    "thresh": 80,          # 밝기 문턱: 이보다 어두우면 선
    "roi_top": 0.45,       # 위쪽에서 버리는 비율
    "look": 0.6,           # 가장 먼 띠 위치 (자른 영역 안, 0 = 위, 1 = 아래)
    "kp": 1.0,
    "kd": 0.5,
    "speed": 0.35,
    "noise": 0.0,          # 주행 조향에 더하는 잡음 크기 (0 = 끔, 참고 0.1 ~ 0.3)
}
BANDS = 3                  # 띠 개수 기본값 (1 또는 3), --bands로 바꿈
NEAR = 0.92                # 띠 3개일 때 가장 가까운 띠 위치
BAND_WEIGHTS = (0.5, 0.3, 0.2)   # 띠 3개 비중 (먼 띠 → 가까운 띠)
BAND_HEIGHT = 0.16         # 띠 높이 (자른 영역 높이에 대한 비율)
SLOWDOWN = 0.4             # 꺾을 때 감속: 속도 × (1 − SLOWDOWN × |조향|)
LOST_STOP = 6              # 선을 놓친 동안 이 프레임 수 전까지는 하던 조향(HOLD, 저장 안 함), 그 뒤 정지
NOISE_HOLD = (0.4, 1.0)    # 잡음 하나를 유지하는 시간(초) 범위
RECORD_FPS = 10


# ---------------------------------------------------------------- 선 찾기
def make_mask(bgr, roi_top, thresh):
    """위쪽 자르기 → 흑백 → 흐리게 → 이진화(어두우면 255) → 작은 점 지우기. 반환 (mask, y0)"""
    y0 = int(bgr.shape[0] * roi_top)
    gray = cv2.cvtColor(bgr[y0:], cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    _, mask = cv2.threshold(gray, int(thresh), 255, cv2.THRESH_BINARY_INV)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    return mask, y0


def band_rows(h, pos, band=BAND_HEIGHT):
    """띠의 위 · 아래 줄 (mask 안 좌표)"""
    b0 = int(np.clip(h * pos - h * band / 2, 0, h - 2))
    b1 = int(np.clip(b0 + h * band, b0 + 2, h))
    return b0, b1


def segments(mask, pos, band=BAND_HEIGHT):
    """띠 하나에서 선 후보들의 가운데 x 목록. 흰 점이 띠 높이의 1/4 이상인 열이 이어진 구간 = 후보 하나"""
    b0, b1 = band_rows(mask.shape[0], pos, band)
    counts = (mask[b0:b1] > 0).sum(axis=0)
    on = counts >= max(2, (b1 - b0) // 4)
    xs, start = [], None
    for x, v in enumerate(list(on) + [False]):
        if v and start is None:
            start = x
        elif not v and start is not None:
            if x - start >= 2:                            # 너무 가는 것(1픽셀)은 잡티
                xs.append((start + x - 1) / 2.0)
            start = None
    return xs


def band_positions(look, bands):
    return [look] if bands == 1 else [look, (look + NEAR) / 2, NEAR]


def find_line(mask, look, bands, last_x=None):
    """띠 1개 또는 3개로 선 위치 x 찾기.
    가까운 띠부터: 기준(지난번 선 x, 처음엔 화면 가운데)에 가장 가까운 후보를 고르고, 그 x를 다음 띠의 기준으로.
    반환: (x 또는 None, [(띠 위치, 고른 x 또는 None, 후보 수), ...]  ← 먼 띠부터)"""
    pos = band_positions(look, bands)
    weights = (1.0,) if bands == 1 else BAND_WEIGHTS
    ref = last_x if last_x is not None else mask.shape[1] / 2
    found = {}
    for i in reversed(range(len(pos))):                   # 가까운 띠부터
        cand = segments(mask, pos[i])
        x = min(cand, key=lambda c: abs(c - ref)) if cand else None
        found[i] = (x, len(cand))
        if x is not None:
            ref = x
    pairs = [(weights[i], found[i][0]) for i in range(len(pos)) if found[i][0] is not None]
    x = sum(w * v for w, v in pairs) / sum(w for w, _ in pairs) if pairs else None
    return x, [(pos[i], found[i][0], found[i][1]) for i in range(len(pos))]


def line_error(x, width):
    return (x - width / 2) / (width / 2)


def pd_steer(error, prev_error, dt, kp, kd):
    change = (error - prev_error) / dt * 0.1 if dt > 0 else 0.0
    return float(np.clip(kp * error + kd * change, -1.0, 1.0))


# ---------------------------------------------------------------- 한 프레임 판단 (카메라 · 모터 없이 시험 가능)
class Driver:
    def __init__(self, bands, seed=None):
        self.bands = bands
        self.prev_err, self.prev_t, self.lost = 0.0, None, 0
        self.last_x, self.last_steer = None, None
        self.noise, self.noise_until = 0.0, 0.0
        self.rng = random.Random(seed)

    def step(self, frame, s, now, auto):
        """반환: dict(steer = 라벨(잡음 없음) 또는 None, drive = 바퀴에 보낼 조향, speed, record 가능 여부, ...)"""
        mask, y0 = make_mask(frame, s["roi_top"], s["thresh"])
        x, bands = find_line(mask, s["look"], self.bands, self.last_x)
        steer = err = None
        if x is not None:
            err = line_error(x, frame.shape[1])
            dt = now - self.prev_t if (self.lost == 0 and self.prev_t is not None) else 0.0
            steer = pd_steer(err, self.prev_err, dt, s["kp"], s["kd"])
            self.prev_err, self.last_x, self.last_steer = err, x, steer
            self.lost = 0
        else:
            self.lost += 1
        self.prev_t = now
        holding = steer is None and self.last_steer is not None and self.lost < LOST_STOP
        if self.lost >= LOST_STOP:
            self.last_x = None                            # 오래 놓쳤으면 다시 가운데부터 찾기
        drive = steer if steer is not None else (self.last_steer if holding else None)
        # 잡음: 선을 보고 있을 때만, 일정 시간마다 새 값 (−noise ~ +noise)
        if s.get("noise", 0) > 0 and steer is not None:
            if now >= self.noise_until:
                self.noise = self.rng.uniform(-s["noise"], s["noise"])
                self.noise_until = now + self.rng.uniform(*NOISE_HOLD)
            drive = float(np.clip(steer + self.noise, -1, 1))
        elif steer is not None:
            self.noise = 0.0
        moving = auto and drive is not None
        speed = s["speed"] * (1 - SLOWDOWN * abs(drive)) if moving else 0.0
        left, right = common.mix(speed, drive) if moving else (0.0, 0.0)
        return {"mask": mask, "y0": y0, "x": x, "bands": bands, "err": err, "steer": steer, "drive": drive,
                "noise": self.noise if steer is not None and s.get("noise", 0) > 0 else 0.0,
                "holding": holding, "lost": self.lost, "moving": moving, "speed": speed,
                "left": left, "right": right, "recordable": moving and steer is not None}


# ---------------------------------------------------------------- 화면
def draw(frame, r, note):
    view = frame.copy()
    h, w = view.shape[:2]
    y0, mask = r["y0"], r["mask"]
    cv2.line(view, (0, y0), (w, y0), (255, 255, 0), 1)                         # 자르는 경계 (하늘색)
    mh = mask.shape[0]
    for pos, x, n in r["bands"]:
        b0, b1 = band_rows(mh, pos)
        color = (0, 200, 0) if n <= 1 else (0, 200, 255)                        # 후보 여러 개면 주황
        cv2.rectangle(view, (0, y0 + b0), (w - 1, y0 + b1), color, 1)
        if x is not None:
            cv2.circle(view, (int(x), y0 + (b0 + b1) // 2), 5, (0, 0, 255), -1)  # 고른 선 (빨강)
    cv2.line(view, (w // 2, y0), (w // 2, h), (255, 255, 255), 1)              # 화면 중심
    if r["x"] is not None:
        cv2.line(view, (int(r["x"]), y0), (int(r["x"]), h), (0, 0, 255), 1)     # 띠들의 가중 평균 x
    if r["steer"] is not None:                                                   # 라벨 (초록)
        tip = (int(w / 2 + r["steer"] * w * 0.4), int(h * 0.55))
        cv2.arrowedLine(view, (w // 2, h - 8), tip, (0, 255, 0), 3, tipLength=0.2)
    if r["drive"] is not None and r["noise"]:                                    # 실제 바퀴 (보라, 잡음 포함)
        tip = (int(w / 2 + r["drive"] * w * 0.4), int(h * 0.6))
        cv2.arrowedLine(view, (w // 2, h - 8), tip, (255, 0, 255), 2, tipLength=0.2)
    cv2.putText(view, note, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    right = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    right = cv2.copyMakeBorder(right, h - right.shape[0], 0, 0, 0, cv2.BORDER_CONSTANT, value=(40, 40, 40))
    return cv2.hconcat([view, right])


def make_note(r, rec_count):
    if r["holding"]:
        return f"HOLD {r['lost']}  steer {r['drive']:+.2f}"
    if r["steer"] is None:
        return "LOST" if r["lost"] else "-"
    t = f"x {r['x']:.0f} err {r['err']:+.2f} label {r['steer']:+.2f}"
    if r["noise"]:
        t += f" noise {r['noise']:+.2f}"
    return t


# ---------------------------------------------------------------- 실행
def create_app(cam, link, bands, settings=None):
    """웹 서버 + 주행 반복 (테스트에서는 가짜 cam · link를 넣음)"""
    from flask import Flask, Response, jsonify, request
    S = dict(settings or SETTINGS)
    st = {"auto": False, "rec": False, "beat": 0.0, "view": None, "info": {}, "recorder": None, "stop": False}
    lock = threading.Lock()
    driver = Driver(bands)
    kind = f"cv{bands}"

    def new_recorder(s):
        return common.Recorder(kind, {"label_source": "opencv", "collect": {
            "tool": "collect_cv.py", "bands": bands, "band_weights": list(BAND_WEIGHTS) if bands == 3 else [1.0],
            "record_fps": RECORD_FPS}, "opencv": s})

    def loop():
        last_save = 0.0
        while not st["stop"]:
            frame = cam.read()
            now = time.time()
            with lock:
                s = dict(S)
                if now - st["beat"] > common.HEARTBEAT:
                    st["auto"] = False                       # 웹 화면 신호가 끊김 → 정지
                auto, rec = st["auto"], st["rec"]
                if rec and st["recorder"] is None:
                    st["recorder"] = new_recorder(s)
                if not rec:
                    st["recorder"] = None                    # 녹화를 다시 켜면 새 세션 폴더
                recorder = st["recorder"]
            r = driver.step(frame, s, now, auto)
            cmd = common.to_command(r["left"], r["right"])
            link.send(cmd)                                   # 매 프레임 전송 = 하트비트
            if recorder and r["recordable"] and now - last_save >= 1.0 / RECORD_FPS:
                last_save = now
                recorder.save(frame, r["steer"], r["speed"])   # 라벨 = 잡음 없는 OpenCV 조향
            count = recorder.count if recorder else 0
            note = make_note(r, count)
            view = draw(frame, r, note)
            with lock:
                st["view"] = view
                st["info"] = {"note": note, "cmd": cmd.strip(), "moving": r["moving"], "frames": count,
                              "folder": recorder.folder if recorder and count else "",
                              "cands": [n for _, _, n in r["bands"]]}

    app = Flask(__name__)
    app.config["state"], app.config["lock"], app.config["loop"] = st, lock, loop

    @app.route("/")
    def index():
        return PAGE.replace("__S__", json.dumps(S)).replace("__BANDS__", str(bands))

    @app.route("/stream")
    def video():
        def get():
            with lock:
                return st["view"]
        return Response(common.mjpeg(get), mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.route("/api", methods=["POST"])
    def api():
        d = request.get_json(silent=True) or {}
        with lock:
            st["auto"], st["rec"], st["beat"] = bool(d.get("auto")), bool(d.get("rec")), time.time()
            for k, v in (d.get("s") or {}).items():
                if k in S:
                    S[k] = float(v)
            return jsonify(st["info"])

    return app


def main():
    ap = argparse.ArgumentParser(description="OpenCV로 달리며 학습 데이터 모으기")
    ap.add_argument("--bands", type=int, choices=[1, 3], default=BANDS, help="띠 개수 (1 = cv_lab 방식, 3 = 먼 곳까지)")
    args = ap.parse_args()
    cam, link = common.open_camera(), common.open_motor()
    app = create_app(cam, link, args.bands)
    threading.Thread(target=app.config["loop"], daemon=True).start()
    print(f"띠 {args.bands}개 · http://<Pi IP>:{PORT}  ·  저장 위치 {common.DATA_ROOT}/<날짜_시간>_cv{args.bands}")
    try:
        app.run(host="0.0.0.0", port=PORT, threaded=True)
    finally:
        link.close()
        cam.close()


PAGE = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>collect_cv</title>
<style>
 body{margin:0;padding:12px;background:#111;color:#eee;font-family:sans-serif}
 img{width:100%;max-width:640px;border-radius:8px;background:#000;display:block}
 button{font-size:18px;padding:10px 18px;margin:8px 6px 8px 0;border:0;border-radius:8px;color:#fff;background:#1e8e3e}
 button.on{background:#d93025} #rec{background:#1a73e8} #rec.on{background:#d93025}
 .sl{display:grid;grid-template-columns:80px 1fr 50px;gap:6px;align-items:center;max-width:640px;font-size:14px}
 .info{font-family:monospace;font-size:15px;color:#f6ad55;margin:8px 0}
 .help{color:#999;font-size:13px;max-width:640px;line-height:1.5}
</style></head><body>
<h3>collect_cv · 띠 __BANDS__개 · 왼쪽 = 카메라, 오른쪽 = 이진화</h3>
<img src="/stream">
<div><button id="go">출발 (Space)</button><button id="rec">녹화 (R)</button></div>
<div class="info" id="info">-</div>
<div id="sliders"></div>
<p class="help">빨간 점 = 띠마다 고른 선 · 주황 띠 = 선 후보가 여러 개 · 초록 화살표 = 저장하는 라벨 · 보라 화살표 = 잡음을 더한 주행 조향<br>
힌트: noise는 OpenCV가 noise 0으로 안정적으로 돌 때 0.1부터 (LOST · 주황 띠가 늘면 낮추기)<br>
선을 본 장면만 1초에 10장 저장 · 녹화를 끄고 다시 켜면 새 폴더 · 창을 닫으면 0.5초 안에 정지</p>
<script>
 const S = __S__, R = {thresh:[0,255,5], roi_top:[0,0.8,0.05], look:[0.1,0.9,0.05], kp:[0,3,0.1], kd:[0,3,0.1], speed:[0.05,0.7,0.05], noise:[0,0.5,0.05]};
 let auto=false, rec=false; const $=id=>document.getElementById(id);
 $('sliders').innerHTML = Object.keys(R).map(k=>`<div class="sl"><span>${k}</span><input id="${k}" type="range" min="${R[k][0]}" max="${R[k][1]}" step="${R[k][2]}" value="${S[k]}"><b id="${k}v">${S[k]}</b></div>`).join('');
 Object.keys(R).forEach(k=>$(k).oninput=()=>{S[k]=Number($(k).value); $(k+'v').textContent=S[k];});
 const render=()=>{$('go').textContent=auto?'정지 (Space)':'출발 (Space)'; $('go').classList.toggle('on',auto); $('rec').classList.toggle('on',rec); $('rec').textContent=rec?'녹화 중지 (R)':'녹화 (R)';};
 $('go').onclick=()=>{auto=!auto;render()}; $('rec').onclick=()=>{rec=!rec;render()};
 document.onkeydown=e=>{if(e.key===' '){e.preventDefault();auto=!auto;render()} if(e.key==='r'||e.key==='R'){rec=!rec;render()}};
 setInterval(async()=>{try{const r=await(await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({auto,rec,s:S})})).json();
   $('info').textContent=`${r.note||''}  ·  명령 ${r.cmd||'-'}  ·  저장 ${r.frames||0}장 ${r.folder?'→ '+r.folder.split('/').slice(-1)[0]:''}`;}catch(e){}},100);
 render();
</script></body></html>"""


if __name__ == "__main__":
    main()
