"""
common.py - 데이터 수집 도구 공용 부품 (collect_cv.py · collect_manual.py가 같이 씀)

  카메라      open_camera()            Pi 카메라 (센서 전체 화각, 180도 회전)
  모터        MotorLink, mix, to_command   motor_lab · cv_lab과 같음
  저장        Recorder                 data/<날짜_시간>_<종류>/images/*.jpg + labels.csv + info.json
  웹 화면     mjpeg(), heartbeat       화면이 닫히면 0.5초 안에 정지

저장 형식은 cv_lab과 같고, dl_lab Colab 노트북이 그대로 읽는다.
  labels.csv : image, steering, throttle, time
  info.json  : 사진이 이미 바로 서 있음(회전 필요 없음) · 수집 방법 · 설정
"""
import csv
import glob
import json
import os
import time

import cv2

SIZE = (320, 240)          # 카메라 해상도 (가로, 세로) - dl_lab 노트북 · 모델과 같아야 함
ROTATE_180 = True          # 카메라를 거꾸로 달았으면 True (화면이 뒤집혀 보이면 반대로)
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(HERE, "data")
LABEL_COLUMNS = ["image", "steering", "throttle", "time"]


# ---------------------------------------------------------------- 모터
def mix(speed, steer):
    """속도 · 조향 → 왼쪽 · 오른쪽 바퀴 (−1 ~ 1). 조향 +면 오른쪽으로 (왼쪽 바퀴가 더 빠름)"""
    left, right = speed * (1 + steer), speed * (1 - steer)
    m = max(abs(left), abs(right), 1.0)
    return left / m, right / m


def to_command(left, right):
    l = int(round(max(-1.0, min(1.0, left)) * 255))
    r = int(round(max(-1.0, min(1.0, right)) * 255))
    return f"M,{l},{r}\n"


class MotorLink:
    """아두이노(motor_serial.ino)에 'M,왼,오' 보내기. 0.5초 동안 명령이 없으면 아두이노가 스스로 정지"""
    def __init__(self, port=None, baud=115200):
        import serial                                   # sudo apt install python3-serial
        ports = sorted(glob.glob("/dev/ttyACM*")) + sorted(glob.glob("/dev/ttyUSB*"))
        self.port = port or (ports[0] if ports else None)
        if self.port is None:
            raise SystemExit("아두이노를 찾을 수 없음: USB 연결 확인")
        self.ser = serial.Serial(self.port, baud, timeout=0.5)
        time.sleep(2)                                   # 포트를 열면 아두이노가 재시작됨
        self.ser.reset_input_buffer()

    def send(self, text):
        self.ser.write(text.encode())

    def close(self):
        try:
            self.send("M,0,0\n")
        finally:
            self.ser.close()


# ---------------------------------------------------------------- 카메라
def full_view_size(cam):
    """센서 전체(가장 넓은 화각)를 쓰는 센서 모드 중 가장 작은 것. 예: Camera Module 2 → (1640, 1232)"""
    try:
        area = lambda m: m["crop_limits"][2] * m["crop_limits"][3]
        widest = max(area(m) for m in cam.sensor_modes)
        full = [m for m in cam.sensor_modes if area(m) >= widest * 0.99]
        return tuple(min(full, key=lambda m: m["size"][0] * m["size"][1])["size"])
    except Exception:
        return None


class Camera:
    """read() → BGR 사진 (240, 320, 3). 이미 바로 선 사진 (ROTATE_180이면 카메라에서 돌림)"""
    def __init__(self):
        from libcamera import Transform
        from picamera2 import Picamera2
        self.cam = Picamera2()
        raw = full_view_size(self.cam)
        print(f"카메라: 센서 모드 {raw or '기본'} → 화면 {SIZE}")
        self.cam.configure(self.cam.create_video_configuration(
            main={"size": SIZE, "format": "RGB888"},       # picamera2의 RGB888 = 메모리상 BGR 순서 (OpenCV와 같음)
            **({"raw": {"size": raw}} if raw else {}),
            transform=Transform(hflip=1, vflip=1) if ROTATE_180 else Transform()))
        self.cam.start()
        time.sleep(1)

    def read(self):
        return self.cam.capture_array("main")

    def close(self):
        self.cam.stop()


def open_camera():
    return Camera()


def open_motor():
    return MotorLink()


# ---------------------------------------------------------------- 저장
class Recorder:
    """세션 폴더 하나에 사진 + labels.csv + info.json 저장.
    폴더는 첫 장을 저장할 때 만든다 (녹화를 켰다 끄기만 하면 빈 폴더가 생기지 않음)."""
    def __init__(self, kind, info):
        self.folder = os.path.join(DATA_ROOT, time.strftime("%Y%m%d_%H%M%S") + "_" + kind)
        self.info = info
        self.count = 0

    def save(self, frame, steering, throttle):
        if self.count == 0:
            os.makedirs(os.path.join(self.folder, "images"), exist_ok=True)
            self.write_info()
            with open(os.path.join(self.folder, "labels.csv"), "w", newline="") as f:
                csv.writer(f).writerow(LABEL_COLUMNS)
        self.count += 1
        name = f"images/{self.count:06d}.jpg"
        cv2.imwrite(os.path.join(self.folder, name), frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
        with open(os.path.join(self.folder, "labels.csv"), "a", newline="") as f:
            csv.writer(f).writerow([name, f"{steering:.3f}", f"{throttle:.3f}", f"{time.time():.3f}"])
        return name

    def write_info(self, **extra):
        """info.json: 노트북이 '이미 바로 선 사진'으로 알고 그대로 씀 (없으면 180도 돌려서 학습 → 거꾸로 꺾음)"""
        self.info.update(extra)
        d = {"version": "data_tools v0", "rotate180": ROTATE_180, "already_upright": True,
             "size": list(SIZE), "created": time.strftime("%Y-%m-%d %H:%M:%S"), **self.info}
        with open(os.path.join(self.folder, "info.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------- 웹 화면
def mjpeg(get_view, fps=15):
    """Flask Response용 MJPEG 스트림"""
    while True:
        v = get_view()
        if v is not None:
            ok, jpg = cv2.imencode(".jpg", v, [cv2.IMWRITE_JPEG_QUALITY, 75])
            if ok:
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg.tobytes() + b"\r\n"
        time.sleep(1.0 / fps)


HEARTBEAT = 0.5            # 웹 화면 신호가 이 시간(초) 동안 없으면 정지
