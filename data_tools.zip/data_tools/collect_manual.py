#!/usr/bin/env python3
"""
collect_manual.py - 사람이 직접 운전하며 학습 데이터 모으기 (라벨 = 내가 누른 조향)

  ↑ (W)  누르고 있는 동안 앞으로      ↓ (S)  누르고 있는 동안 뒤로 (저장 안 함)
  ← → (A D)  조향 ±steer_key           Shift와 함께  ±1.0 (크게 꺾기)
  Space  녹화 켜기 / 끄기              휴대폰: 화면의 ◀ ▲ ▶ ▼ 버튼을 누르고 있기

  - 앞으로 가는 동안만 1초에 10장 저장 (멈춰 있거나 뒤로 갈 때는 저장 안 함)
  - smooth 슬라이더 (처음 0, 단위 초): 0보다 크면 조향이 목표값까지 천천히 바뀜 (0 → 1에 smooth초) → 바퀴가 덜 덜컥이고,
    라벨이 −0.5 / 0 / +0.5 사이 값도 가짐 (조금 꺾은 장면)
  - 선에서 일부러 조금 벗어났다가 돌아오는 장면도 섞어 주면 모델이 '돌아오는 법'을 배움
    (단, 벗어나는 동안은 녹화를 끄고, 돌아오는 동안만 녹화 → 잘못된 라벨을 배우지 않게)

실행 (Pi 5):
  source venv/bin/activate
  python3 collect_manual.py          → 브라우저 http://<Pi IP>:8000 (키보드가 있는 PC 브라우저 권장)

저장: data/<날짜_시간>_manual/ (images/, labels.csv, info.json) → dataset_tool.py로 확인 · 정리
"""
import json
import threading
import time

import cv2
import numpy as np

import common

PORT = 8000
SETTINGS = {
    "speed": 0.3,          # 앞으로 갈 때 속도
    "steer_key": 0.5,      # ← → 를 눌렀을 때 조향 (Shift = 1.0)
    "smooth": 0.0,         # 조향이 0 → 1만큼 바뀌는 데 걸리는 시간(초, 0 = 바로). 0.3이면 0 → 0.5에 0.15초
}
SLOWDOWN = 0.4             # 꺾을 때 감속: 속도 × (1 − SLOWDOWN × |조향|)
REVERSE_SPEED = 0.25
RECORD_FPS = 10


class Pilot:
    """키 상태 → 조향 · 속도 (카메라 · 모터 없이 시험 가능)"""
    def __init__(self):
        self.steer, self.prev_t = 0.0, None

    def step(self, keys, s, now):
        """keys: {'up','down','left','right','shift'} 중 눌린 것. 반환 dict(steer, speed, left, right, forward)"""
        big = 1.0 if "shift" in keys else s["steer_key"]
        target = (big if "right" in keys else 0.0) - (big if "left" in keys else 0.0)
        dt = 0.0 if self.prev_t is None else max(0.0, now - self.prev_t)
        self.prev_t = now
        if s["smooth"] > 0:                               # 한 프레임에 최대 dt ÷ smooth 만큼만 바뀜
            step = dt / s["smooth"]
            self.steer += float(np.clip(target - self.steer, -step, step))
        else:
            self.steer = target
        forward, back = "up" in keys and "down" not in keys, "down" in keys and "up" not in keys
        if forward:
            speed = s["speed"] * (1 - SLOWDOWN * abs(self.steer))
        elif back:
            speed = -REVERSE_SPEED
        else:
            speed = 0.0
        # 뒤로 갈 때는 조향 방향을 그대로 두면 바퀴 차이가 반대로 작용 → mix가 알아서 처리 (속도가 음수)
        left, right = common.mix(speed, self.steer) if speed else (0.0, 0.0)
        return {"steer": self.steer, "target": target, "speed": speed, "left": left, "right": right,
                "forward": forward}


def draw(frame, r, note, rec):
    view = frame.copy()
    h, w = view.shape[:2]
    cv2.line(view, (w // 2, int(h * 0.5)), (w // 2, h), (255, 255, 255), 1)           # 화면 중심
    tip = (int(w / 2 + r["steer"] * w * 0.4), int(h * 0.55))
    color = (0, 255, 0) if r["forward"] else (0, 165, 255)
    cv2.arrowedLine(view, (w // 2, h - 8), tip, color, 3, tipLength=0.2)               # 지금 조향 = 라벨
    if rec:
        cv2.circle(view, (w - 14, 14), 7, (0, 0, 255), -1)                              # 녹화 중 (빨간 점)
    cv2.putText(view, note, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    return view


def create_app(cam, link, settings=None):
    from flask import Flask, Response, jsonify, request
    S = dict(settings or SETTINGS)
    st = {"keys": set(), "rec": False, "beat": 0.0, "view": None, "info": {}, "recorder": None, "stop": False}
    lock = threading.Lock()
    pilot = Pilot()

    def loop():
        last_save = 0.0
        while not st["stop"]:
            frame = cam.read()
            now = time.time()
            with lock:
                s = dict(S)
                if now - st["beat"] > common.HEARTBEAT:
                    st["keys"] = set()                       # 웹 화면 신호가 끊김 → 정지
                keys, rec = set(st["keys"]), st["rec"]
                if rec and st["recorder"] is None:
                    st["recorder"] = common.Recorder("manual", {"label_source": "manual", "collect": {
                        "tool": "collect_manual.py", "record_fps": RECORD_FPS, "steer_key": s["steer_key"],
                        "steer_key_shift": 1.0, "smooth": s["smooth"]}, "default_speed": s["speed"]})
                if not rec:
                    st["recorder"] = None                    # 녹화를 다시 켜면 새 세션 폴더
                recorder = st["recorder"]
            r = pilot.step(keys, s, now)
            cmd = common.to_command(r["left"], r["right"])
            link.send(cmd)                                   # 매 프레임 전송 = 하트비트
            if recorder and r["forward"] and now - last_save >= 1.0 / RECORD_FPS:
                last_save = now
                recorder.save(frame, r["steer"], r["speed"])
            count = recorder.count if recorder else 0
            note = f"steer {r['steer']:+.2f}  speed {r['speed']:+.2f}" + ("  REC" if rec else "")
            view = draw(frame, r, note, rec)
            with lock:
                st["view"] = view
                st["info"] = {"note": note, "cmd": cmd.strip(), "frames": count, "rec": rec,
                              "folder": recorder.folder if recorder and count else ""}

    app = Flask(__name__)
    app.config["state"], app.config["lock"], app.config["loop"] = st, lock, loop

    @app.route("/")
    def index():
        return PAGE.replace("__S__", json.dumps(S))

    @app.route("/stream")
    def video():
        def get():
            with lock:
                return st["view"]
        return Response(common.mjpeg(get), mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.route("/api", methods=["POST"])
    def api():
        d = request.get_json(silent=True) or {}
        with lock:
            st["keys"] = {k for k in (d.get("keys") or []) if k in ("up", "down", "left", "right", "shift")}
            st["rec"], st["beat"] = bool(d.get("rec")), time.time()
            for k, v in (d.get("s") or {}).items():
                if k in S:
                    S[k] = float(v)
            return jsonify(st["info"])

    return app


def main():
    cam, link = common.open_camera(), common.open_motor()
    app = create_app(cam, link)
    threading.Thread(target=app.config["loop"], daemon=True).start()
    print(f"http://<Pi IP>:{PORT}  ·  저장 위치 {common.DATA_ROOT}/<날짜_시간>_manual")
    try:
        app.run(host="0.0.0.0", port=PORT, threaded=True)
    finally:
        link.close()
        cam.close()


PAGE = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"><title>collect_manual</title>
<style>
 body{margin:0;padding:12px;background:#111;color:#eee;font-family:sans-serif;user-select:none;-webkit-user-select:none}
 img{width:100%;max-width:640px;border-radius:8px;background:#000;display:block}
 #rec{font-size:18px;padding:10px 18px;margin:8px 6px 8px 0;border:0;border-radius:8px;color:#fff;background:#1a73e8}
 #rec.on{background:#d93025}
 .pad{display:grid;grid-template-columns:repeat(3,76px);grid-template-rows:repeat(2,64px);gap:8px;margin:8px 0;touch-action:none}
 .pad button{font-size:26px;border:0;border-radius:10px;background:#3c4043;color:#fff}
 .pad button.on{background:#1e8e3e}
 .sl{display:grid;grid-template-columns:80px 1fr 50px;gap:6px;align-items:center;max-width:640px;font-size:14px}
 .info{font-family:monospace;font-size:15px;color:#f6ad55;margin:8px 0}
 .help{color:#999;font-size:13px;max-width:640px;line-height:1.5}
</style></head><body>
<h3>collect_manual · 직접 운전하며 모으기</h3>
<img src="/stream">
<div><button id="rec">녹화 (Space)</button></div>
<div class="pad">
 <span></span><button data-k="up">▲</button><span></span>
 <button data-k="left">◀</button><button data-k="down">▼</button><button data-k="right">▶</button>
</div>
<div class="info" id="info">-</div>
<div id="sliders"></div>
<p class="help">↑ W 앞으로 · ↓ S 뒤로 · ← → A D 조향 (Shift = 크게) · 누르고 있는 동안만 움직임<br>
앞으로 가는 동안만 1초에 10장 저장 · 녹화를 끄고 다시 켜면 새 폴더 · 창을 닫거나 다른 창을 누르면 정지</p>
<script>
 const S = __S__, R = {speed:[0.1,0.7,0.05], steer_key:[0.2,1,0.05], smooth:[0,1,0.05]};
 const KEYMAP = {ArrowUp:'up',w:'up',W:'up',ArrowDown:'down',s:'down',S:'down',ArrowLeft:'left',a:'left',A:'left',ArrowRight:'right',d:'right',D:'right'};
 const keys = new Set(), touch = new Set(); let rec=false, shift=false; const $=id=>document.getElementById(id);
 $('sliders').innerHTML = Object.keys(R).map(k=>`<div class="sl"><span>${k}</span><input id="${k}" type="range" min="${R[k][0]}" max="${R[k][1]}" step="${R[k][2]}" value="${S[k]}"><b id="${k}v">${S[k]}</b></div>`).join('');
 Object.keys(R).forEach(k=>$(k).oninput=()=>{S[k]=Number($(k).value); $(k+'v').textContent=S[k]; $(k).blur();});
 const pressed=()=>{const a=new Set([...keys,...touch]); if(shift) a.add('shift'); return [...a];};
 const render=()=>{$('rec').classList.toggle('on',rec); $('rec').textContent=rec?'녹화 중지 (Space)':'녹화 (Space)';
   const p=pressed(); document.querySelectorAll('.pad button').forEach(b=>b.classList.toggle('on',p.includes(b.dataset.k)));};
 $('rec').onclick=()=>{rec=!rec;render();$('rec').blur()};
 document.addEventListener('keydown',e=>{shift=e.shiftKey; if(e.key===' '){e.preventDefault(); if(!e.repeat){rec=!rec}} const k=KEYMAP[e.key]; if(k){e.preventDefault(); keys.add(k)} render()});
 document.addEventListener('keyup',e=>{shift=e.shiftKey; const k=KEYMAP[e.key]; if(k) keys.delete(k); render()});
 window.addEventListener('blur',()=>{keys.clear(); touch.clear(); shift=false; render()});
 document.querySelectorAll('.pad button').forEach(b=>{
   const on=e=>{e.preventDefault(); touch.add(b.dataset.k); render()}, off=e=>{e.preventDefault(); touch.delete(b.dataset.k); render()};
   b.addEventListener('pointerdown',on); b.addEventListener('pointerup',off); b.addEventListener('pointerleave',off); b.addEventListener('pointercancel',off);});
 setInterval(async()=>{try{const r=await(await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keys:pressed(),rec,s:S})})).json();
   $('info').textContent=`${r.note||''}  ·  명령 ${r.cmd||'-'}  ·  저장 ${r.frames||0}장 ${r.folder?'→ '+r.folder.split('/').slice(-1)[0]:''}`;}catch(e){}},100);
 render();
</script></body></html>"""


if __name__ == "__main__":
    main()
