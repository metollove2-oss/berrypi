#!/usr/bin/env python3
"""
dl_lab.py - 딥러닝 선 따라가기 실습: 학습한 모델로 달리기 [학생]

Colab에서 학습한 분류 모델(line_model.onnx)이 카메라 사진을 보고 왼쪽 / 직진 / 오른쪽을 고르면,
그 단계의 조향값으로 차를 움직인다. 선이 보이는지는 OpenCV(cv_lab의 C1 · C2)로 확인한다 = 하이브리드.

  [P1] to_blob()          카메라 사진 → 모델 입력 (Colab D1과 같은 전처리 + (1, 3, 66, 200) float32)
  [P2] choose_steering()  모델 출력(단계별 확률) → 조향값
  [P3] hybrid()           선이 보이면 모델, 잠깐 놓치면 하던 조향(HOLD), 계속 놓치면 정지
  [제공] C1 make_mask, C2 find_line_x (cv_lab 정답), 모델 불러오기 · 실행, 카메라, 웹 화면, 모터, 주행 반복

준비 (Pi 5, 한 번만) - 자세한 내용은 README.txt:
  sudo apt install -y python3-venv python3-picamera2 python3-opencv python3-numpy python3-flask python3-serial
  python3 -m venv --system-site-packages venv      # dl_lab 폴더에서
  아두이노에는 arduino/motor_serial/motor_serial.ino 업로드

실행 (Pi 5, 카메라 + 아두이노 USB + 모터 배터리):
  source venv/bin/activate
  python3 check_dl.py                                   # 먼저 카메라 · 모터 없이 P1 ~ P3 확인
  python3 dl_lab.py --model models_synth/line_model.onnx  # 합성 데이터로 미리 학습해 둔 모델
  python3 dl_lab.py                                     # Colab에서 받은 models/line_model.onnx
  브라우저: http://<Pi IP>:8000  →  '출발'
"""
import argparse
import glob
import json
import os
import threading
import time

import cv2
import numpy as np

# ================= 설정 =================
SIZE = (320, 240)          # 카메라 해상도 (가로, 세로) - 학습 데이터와 같아야 함
ROTATE_180 = True          # 카메라를 거꾸로 달았으면 True (화면이 뒤집혀 보이면 반대로)
PORT = 8000
SETTINGS = {               # 웹 화면 슬라이더로 바꾸는 값 (처음 값)
    "speed": 0.3,          # 속도 (처음엔 느리게)
    "thresh": 80,          # 선 확인용 (C1): 이보다 어두우면 선
    "roi_top": 0.45,       # 선 확인용 (C1): 위쪽에서 버리는 비율
    "look": 0.6,           # 선 확인용 (C2): 살펴볼 띠 위치
}
SLOWDOWN = 0.4             # 꺾을 때 속도 줄이기: 실제 속도 = 속도 × (1 − SLOWDOWN × |조향|)
LOST_STOP = 6              # 선을 놓친 동안 이 프레임 수 전까지는 하던 조향 그대로 (HOLD),
                           # 이만큼 연속으로 못 찾으면 정지 (20fps에서 약 0.3초)
HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(HERE, "models", "line_model.onnx")


# ---------------------------------------------------------------------
# [제공] 선 확인용: cv_lab의 C1 · C2 정답
# ---------------------------------------------------------------------
def make_mask(bgr, roi_top, thresh):
    y0 = int(bgr.shape[0] * roi_top)
    gray = cv2.GaussianBlur(cv2.cvtColor(bgr[y0:], cv2.COLOR_BGR2GRAY), (5, 5), 0)
    _, mask = cv2.threshold(gray, int(thresh), 255, cv2.THRESH_BINARY_INV)
    return cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)), y0


def find_line_x(mask, look, band=0.16):
    h = mask.shape[0]
    b0 = int(np.clip(h * look - h * band / 2, 0, h - 2))
    b1 = int(np.clip(b0 + h * band, b0 + 2, h))
    cols = np.where((mask[b0:b1] > 0).sum(axis=0) >= max(2, (b1 - b0) // 4))[0]
    return None if len(cols) == 0 else float(cols.mean())


# =====================================================================
# [P1] 카메라 사진 → 모델 입력
#   1) Colab D1과 똑같이: 위쪽 crop_top_ratio 비율 자르기 → size(가로, 세로)로 줄이기 (cv2.INTER_AREA)
#   2) (세로, 가로, 3) → (3, 세로, 가로)  : transpose(2, 0, 1)   (색 채널을 맨 앞으로)
#   3) 맨 앞에 '사진 개수' 차원 추가 → (1, 3, 세로, 가로)  : [np.newaxis]
#   4) float32로  : .astype(np.float32)    값은 0 ~ 255 그대로 (−1 ~ 1 바꾸기는 모델 안에서 함)
#   예: (240, 320, 3) uint8, crop 0.4, size (200, 66) → (1, 3, 66, 200) float32
#   BGR 순서 그대로 (학습할 때도 cv2.imread의 BGR로 학습함)
# =====================================================================
def to_blob(bgr, crop_top_ratio, size):
    # TODO P1: (힌트: bgr.shape[0], bgr[y:], cv2.resize(..., size, interpolation=cv2.INTER_AREA),
    #          .transpose(2, 0, 1), [np.newaxis], .astype(np.float32))
    raise NotImplementedError("P1")


# =====================================================================
# [P2] 모델 출력 → 조향값
#   probs: 단계별 확률 [왼쪽, 직진, 오른쪽]  (합 = 1, 모델이 softmax까지 해서 내보냄)
#   class_steering: 단계별 조향값 (model_config.json, 예: [-0.55, 0.0, 0.55])
#   가장 확률이 큰 단계를 고르고, 그 단계의 조향값을 씀
#   반환: (조향값 float, 고른 단계 번호 int, 그 확률 float)
#   예: probs [0.1, 0.2, 0.7] → (0.55, 2, 0.7)
# =====================================================================
def choose_steering(probs, class_steering):
    # TODO P2: (힌트: np.argmax(probs) → int(...), class_steering[i], float(probs[i]))
    raise NotImplementedError("P2")


# =====================================================================
# [P3] 하이브리드: 모델 조향 + OpenCV 선 확인
#   model_steer: 이번 프레임 모델의 조향값,  line_x: C2 결과 (선이 없으면 None)
#   lost: 지금까지 연속으로 선을 놓친 프레임 수,  last_steer: 마지막으로 선을 보며 쓴 조향 (없으면 None)
#   반환: (steer, lost, last_steer, mode)
#     선이 보임            → (model_steer, 0, model_steer, "model")
#     안 보임: lost + 1 하고
#       last_steer가 있고 lost < LOST_STOP → (last_steer, lost, last_steer, "hold")   하던 대로
#       아니면                             → (None, lost, last_steer, "stop")         정지
#   (cv_lab 주행 반복의 HOLD와 같은 규칙. 왜? 모델은 선이 없는 사진을 배운 적이 없어 그때 출력을 믿을 수 없음)
# =====================================================================
def hybrid(model_steer, line_x, lost, last_steer):
    # TODO P3: (힌트: if line_x is not None: ...  /  lost += 1  /  LOST_STOP과 비교)
    raise NotImplementedError("P3")


# ---------------------------------------------------------------------
# [제공] 모델 불러오기 · 실행 (Pi에는 PyTorch가 없어도 됨: OpenCV DNN으로 ONNX 실행)
# ---------------------------------------------------------------------
def load_model(model_path):
    cfg_path = os.path.join(os.path.dirname(model_path), "model_config.json")
    for p in (model_path, cfg_path):
        if not os.path.isfile(p):
            raise SystemExit(f"모델 파일이 없음: {p}\n  Colab 마지막 셀에서 받은 line_model.onnx, model_config.json을 "
                             f"models/ 에 넣거나, 합성 모델로 먼저: python3 dl_lab.py --model models_synth/line_model.onnx")
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)
    if cfg.get("model_type") != "classification":
        raise SystemExit("dl_lab은 분류 모델만 실행합니다 (model_config.json의 model_type)")
    return cv2.dnn.readNetFromONNX(model_path), cfg


def run_model(net, blob):
    net.setInput(blob)
    return np.ravel(net.forward())          # (1, 3) → [왼쪽, 직진, 오른쪽] 확률


# ---------------------------------------------------------------------
# [제공] 모터 (motor_lab과 같음)
# ---------------------------------------------------------------------
def mix(speed, steer):
    left, right = speed * (1 + steer), speed * (1 - steer)
    m = max(abs(left), abs(right), 1.0)
    return left / m, right / m


def to_command(left, right):
    l = int(round(max(-1.0, min(1.0, left)) * 255))
    r = int(round(max(-1.0, min(1.0, right)) * 255))
    return f"M,{l},{r}\n"


class MotorLink:
    def __init__(self, port=None, baud=115200):
        import serial                                   # sudo apt install python3-serial
        ports = sorted(glob.glob("/dev/ttyACM*")) + sorted(glob.glob("/dev/ttyUSB*"))
        self.port = port or (ports[0] if ports else None)
        if self.port is None:
            raise SystemExit("아두이노를 찾을 수 없음: USB 연결 확인")
        self.ser = serial.Serial(self.port, baud, timeout=0.5)
        time.sleep(2)                                   # 포트를 열면 아두이노가 재시작됨
        self.ser.reset_input_buffer()

    def send(self, text):
        self.ser.write(text.encode())

    def close(self):
        try:
            self.send("M,0,0\n")
        finally:
            self.ser.close()


# ---------------------------------------------------------------------
# [제공] 화면 그리기: 왼쪽 = 카메라 + 모델이 고른 단계 확률 막대, 오른쪽 = 선 확인용 mask
# ---------------------------------------------------------------------
MODE_COLOR = {"model": (0, 200, 0), "hold": (0, 200, 255), "stop": (0, 0, 255), "-": (160, 160, 160)}


def draw(frame, y0, mask, look, line_x, probs, names, steer, mode, moving, note):
    view = frame.copy()
    h, w = view.shape[:2]
    cv2.line(view, (0, y0), (w, y0), (255, 255, 0), 1)
    if mask is not None:
        mh = mask.shape[0]
        b0, b1 = y0 + int(mh * look - mh * 0.08), y0 + int(mh * look + mh * 0.08)
        cv2.rectangle(view, (0, b0), (w - 1, b1), (0, 200, 0), 1)
        if line_x is not None:
            cv2.circle(view, (int(line_x), (b0 + b1) // 2), 5, (0, 0, 255), -1)
    if probs is not None:                                          # 단계별 확률 막대 (아래쪽)
        bw = w // len(probs)
        for i, p in enumerate(probs):
            x0 = i * bw + 4
            cv2.rectangle(view, (x0, h - 22), (x0 + int((bw - 8) * p), h - 6),
                          (0, 165, 255) if i == int(np.argmax(probs)) else (120, 120, 120), -1)
            cv2.putText(view, f"{names[i][:5]} {p:.0%}", (x0, h - 26), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    if steer is not None:
        tip = (int(w / 2 + steer * w * 0.4), int(h * 0.5))
        cv2.arrowedLine(view, (w // 2, h - 40), tip, (0, 255, 0) if moving else (0, 165, 255), 3, tipLength=0.2)
    cv2.putText(view, note, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, MODE_COLOR.get(mode, (255, 255, 255)), 1)
    right = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR) if mask is not None else np.zeros((1, w, 3), np.uint8)
    right = cv2.copyMakeBorder(right, h - right.shape[0], 0, 0, 0, cv2.BORDER_CONSTANT, value=(40, 40, 40))
    return cv2.hconcat([view, right])


def full_view_size(cam):
    """센서 전체(가장 넓은 화각)를 쓰는 센서 모드 중 가장 작은 것 (cv_lab과 같음, 학습 데이터와 같은 화각)"""
    try:
        area = lambda m: m["crop_limits"][2] * m["crop_limits"][3]
        widest = max(area(m) for m in cam.sensor_modes)
        full = [m for m in cam.sensor_modes if area(m) >= widest * 0.99]
        return tuple(min(full, key=lambda m: m["size"][0] * m["size"][1])["size"])
    except Exception:
        return None


# ---------------------------------------------------------------------
# [제공] 카메라 + 주행 반복 + 웹 화면
# ---------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="dl_lab: 학습한 모델로 선 따라가기")
    ap.add_argument("--model", default=MODEL_PATH, help="ONNX 파일 (같은 폴더에 model_config.json)")
    args = ap.parse_args()
    net, cfg = load_model(args.model)
    names = cfg.get("classes", ["left", "straight", "right"])
    crop, size = cfg["crop_top_ratio"], (cfg["input_width"], cfg["input_height"])
    print(f"모델: {args.model} · 단계별 조향값 {cfg['class_steering']} · 검증 정확도 {cfg.get('val_accuracy')}")

    from flask import Flask, Response, jsonify, request
    from libcamera import Transform
    from picamera2 import Picamera2

    cam = Picamera2()
    raw = full_view_size(cam)
    print(f"카메라: 센서 모드 {raw or '기본'} → 화면 {SIZE}")
    cam.configure(cam.create_video_configuration(
        main={"size": SIZE, "format": "RGB888"}, **({"raw": {"size": raw}} if raw else {}),
        transform=Transform(hflip=1, vflip=1) if ROTATE_180 else Transform()))
    cam.start()
    time.sleep(1)
    link = MotorLink()
    S = dict(SETTINGS)
    st = {"auto": False, "beat": 0.0, "view": None, "info": {}}
    lock = threading.Lock()

    def loop():
        lost, last_steer = 0, None
        while True:
            frame = cam.capture_array("main")
            now = time.time()
            with lock:
                s = dict(S)
                if now - st["beat"] > 0.5:
                    st["auto"] = False                       # 웹 화면 신호가 끊김 → 정지
                auto = st["auto"]
            mask, y0 = make_mask(frame, s["roi_top"], s["thresh"])
            line_x = find_line_x(mask, s["look"])
            probs = steer = None
            mode, note = "-", ""
            t0 = time.time()
            try:
                probs = run_model(net, to_blob(frame, crop, size))                 # P1 + 모델
                ms = (time.time() - t0) * 1000
                model_steer, idx, p = choose_steering(probs, cfg["class_steering"])  # P2
                steer, lost, last_steer, mode = hybrid(model_steer, line_x, lost, last_steer)   # P3
                note = f"{mode.upper()}  {names[idx]} {p:.0%} -> steer {model_steer:+.2f}  ({ms:.0f}ms)"
                if mode != "model":
                    note = f"{mode.upper()} {lost}  " + ("steer {:+.2f}".format(steer) if steer is not None else "line lost")
            except NotImplementedError as e:
                note = f"{e} 아직"
            except cv2.error as e:
                note = "모델 입력 오류: P1의 모양 (1, 3, 66, 200) float32 확인"
                print(e)
            moving = auto and steer is not None
            if moving:
                left, right = mix(s["speed"] * (1 - SLOWDOWN * abs(steer)), steer)
            else:
                left = right = 0.0
            cmd = to_command(left, right)
            link.send(cmd)                                   # 매 프레임 전송 = 하트비트
            view = draw(frame, y0, mask, s["look"], line_x, probs, names, steer, mode, moving, note)
            with lock:
                st["view"] = view
                st["info"] = {"note": note, "cmd": cmd.strip(), "mode": mode, "moving": moving,
                              "probs": None if probs is None else [round(float(v), 3) for v in probs]}

    threading.Thread(target=loop, daemon=True).start()
    app = Flask(__name__)

    def stream():
        while True:
            with lock:
                v = st["view"]
            if v is not None:
                ok, jpg = cv2.imencode(".jpg", v, [cv2.IMWRITE_JPEG_QUALITY, 75])
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg.tobytes() + b"\r\n"
            time.sleep(0.07)

    @app.route("/")
    def index():
        return PAGE.replace("__S__", json.dumps(S))

    @app.route("/stream")
    def video():
        return Response(stream(), mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.route("/api", methods=["POST"])
    def api():
        d = request.get_json(silent=True) or {}
        with lock:
            st["auto"], st["beat"] = bool(d.get("auto")), time.time()
            for k, v in (d.get("s") or {}).items():
                if k in S:
                    S[k] = float(v)
            return jsonify(st["info"])

    print(f"http://<Pi IP>:{PORT}")
    try:
        app.run(host="0.0.0.0", port=PORT, threaded=True)
    finally:
        link.close()
        cam.stop()


PAGE = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>dl_lab</title>
<style>
 body{margin:0;padding:12px;background:#111;color:#eee;font-family:sans-serif}
 img{width:100%;max-width:640px;border-radius:8px;background:#000;display:block}
 button{font-size:18px;padding:10px 18px;margin:8px 6px 8px 0;border:0;border-radius:8px;color:#fff;background:#1e8e3e}
 button.on{background:#d93025}
 .sl{display:grid;grid-template-columns:80px 1fr 50px;gap:6px;align-items:center;max-width:640px;font-size:14px}
 .info{font-family:monospace;font-size:15px;color:#f6ad55;margin:8px 0}
</style></head><body>
<h3>dl_lab: 왼쪽 = 카메라 (아래 막대 = 모델의 단계별 확률), 오른쪽 = 선 확인용 mask</h3>
<img src="/stream">
<div><button id="go">출발 (Space)</button></div>
<div class="info" id="info">-</div>
<div id="sliders"></div>
<p style="color:#999;font-size:13px">MODEL = 모델로 주행 · HOLD = 선을 잠깐 놓쳐 하던 조향 · STOP = 선을 계속 놓쳐 정지 · 창을 닫으면 0.5초 안에 정지</p>
<script>
 const S = __S__, R = {speed:[0.05,0.7,0.05], thresh:[0,255,5], roi_top:[0,0.8,0.05], look:[0.1,0.9,0.05]};
 let auto=false; const $=id=>document.getElementById(id);
 $('sliders').innerHTML = Object.keys(R).map(k=>`<div class="sl"><span>${k}</span><input id="${k}" type="range" min="${R[k][0]}" max="${R[k][1]}" step="${R[k][2]}" value="${S[k]}"><b id="${k}v">${S[k]}</b></div>`).join('');
 Object.keys(R).forEach(k=>$(k).oninput=()=>{S[k]=Number($(k).value); $(k+'v').textContent=S[k];});
 const render=()=>{$('go').textContent=auto?'정지 (Space)':'출발 (Space)'; $('go').classList.toggle('on',auto);};
 $('go').onclick=()=>{auto=!auto;render()};
 document.onkeydown=e=>{if(e.key===' '){e.preventDefault();auto=!auto;render()}};
 setInterval(async()=>{try{const r=await(await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({auto,s:S})})).json();
   $('info').textContent=`${r.note||''}  ·  명령 ${r.cmd||'-'}`;}catch(e){}},100);
 render();
</script></body></html>"""


if __name__ == "__main__":
    main()
