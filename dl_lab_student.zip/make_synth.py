#!/usr/bin/env python3
"""
make_synth.py - 합성 학습 데이터 만들기 (dl_lab)

진짜 데이터를 모으기 전에 학습 · 주행 흐름을 먼저 돌려 보기 위한 가짜 사진.
Pi 카메라 높이(약 12cm) · 기울기에서 본 것처럼, 밝은 바닥 위의 검은 선(직선 · 커브 · S자)을 그리고,
그 장면에서 '선을 따라가려면 얼마나 꺾어야 하는지'를 계산해 조향값(라벨)으로 저장한다.

저장 형식은 collect.py와 같음 → 학습 노트북 · label_edit.py에서 그대로 사용
  data/synth_<개수>/images/000001.jpg ...
  data/synth_<개수>/labels.csv   (image, steering, throttle, time, left, right, mode, step)
  data/synth_<개수>/info.json    (label_source: "synthetic")

실행:  python3 make_synth.py              (3000장, 약 10초)
       python3 make_synth.py 600 --out data
주의: 합성 사진은 진짜 트랙과 다르다. 흐름 확인용이고, 실제 주행 모델은 직접 모은 데이터로 학습할 것.
"""
import csv
import json
import math
import os
import sys

import cv2
import numpy as np

W, H = 320, 240               # 카메라 사진 크기 (linecar와 같음)
RES = 0.25                    # 바닥 그림 해상도 (cm / 픽셀)
GX, GZ = 120, 100             # 바닥 그림 범위: 좌우 ±60cm, 앞 0 ~ 100cm
LOOK_AHEAD = 20.0             # 라벨 계산: 이만큼 앞(cm)의 선 위치를 봄 (pure pursuit)
GAIN = 1.2                    # 조향 = GAIN × (앞쪽 선의 좌우 위치 ÷ LOOK_AHEAD)
EDGE = 0.25                   # 3단계 경계 (linecar 기본: 키 조향값 0.5의 절반)
MIN_LINE_PIXELS = 600         # 아래쪽 60%에 선이 이만큼(픽셀)은 보여야 사용 (collect_cv처럼 선 없는 장면 제외)


def camera_map(rng):
    """카메라 사진의 각 픽셀이 바닥의 어디(좌우 X, 앞 Z, cm)를 보는지 → 바닥 그림 좌표"""
    h = rng.uniform(11, 13)                       # 카메라 높이 (cm)
    tilt = math.radians(rng.uniform(32, 40))      # 아래로 기울인 각도
    f = (W / 2) / math.tan(math.radians(rng.uniform(29, 33)))   # 가로 화각 약 58 ~ 66도
    u, v = np.meshgrid(np.arange(W) + 0.5, np.arange(H) + 0.5)
    x, y = (u - W / 2) / f, (v - H / 2) / f
    down = y * math.cos(tilt) + math.sin(tilt)
    fwd = math.cos(tilt) - y * math.sin(tilt)
    t = h / np.maximum(down, 1e-3)
    X, Z = t * x, t * fwd
    mx = ((X + GX / 2) / RES).astype(np.float32)
    my = ((GZ - Z) / RES).astype(np.float32)          # 바닥 그림에서 위 = 먼 곳
    return mx, my


def line_points(rng):
    """차 앞 바닥에 그릴 선 (cm). 지금 위치의 좌우 x0, 방향 psi, 구간별 곡률"""
    x0 = rng.uniform(-9, 9)
    psi = math.radians(rng.uniform(-35, 35))          # + = 오른쪽으로 기울어짐
    kind = rng.random()
    def curv():
        if rng.random() < 0.35:
            return 0.0
        r = rng.uniform(12, 60)                        # 커브 반지름 (cm)
        return rng.choice([-1, 1]) / r
    k1, k2 = curv(), curv()
    split = rng.uniform(10, 60) if kind < 0.5 else 1e9    # 절반은 중간에 곡률이 바뀜 (S자 등)
    pts, step = [], 0.5
    for sign in (1, -1):                              # 앞쪽, 뒤쪽으로 이어 그리기
        x, z, a, s = x0, 0.0, psi, 0.0
        seg = []
        while s < (130 if sign > 0 else 25) and abs(a - psi) < math.radians(150):   # 한 바퀴 돌아 고리가 되지 않게
            k = (k1 if s < split else k2) if sign > 0 else k1
            a += sign * k * step
            x += sign * math.sin(a) * step
            z += sign * math.cos(a) * step
            s += step
            seg.append((x, z))
        pts = seg if sign > 0 else seg[::-1] + [(x0, 0.0)] + pts
    return np.array(pts)


def steering_label(pts):
    """선 위에서 차(원점)로부터 LOOK_AHEAD만큼 떨어진 앞쪽 점 → 그 점의 좌우 위치로 조향"""
    d = np.hypot(pts[:, 0], pts[:, 1])
    i0 = int(np.argmin(d))                            # 선에서 차와 가장 가까운 점
    ahead = np.where((np.arange(len(pts)) >= i0) & (d >= LOOK_AHEAD) & (pts[:, 1] > 0))[0]
    if len(ahead) == 0:
        return None
    x_t = pts[ahead[0], 0]
    return float(np.clip(GAIN * x_t / LOOK_AHEAD, -1, 1))


def floor_image(rng, pts):
    """바닥 그림: 밝은 바닥 + 이음새 + 검은 선. (그림, 선만 255인 그림) 반환"""
    gw, gh = int(GX / RES), int(GZ / RES)
    if rng.random() < 0.6:                            # MDF 퍼즐 매트 색 / 흰 종이 · 밝은 바닥
        base = np.array([140, 175, 205]) * rng.uniform(0.85, 1.1) + rng.uniform(-8, 8, 3)
    else:
        base = np.full(3, rng.uniform(185, 235)) + rng.uniform(-8, 8, 3)
    img = np.empty((gh, gw, 3), np.float32)
    img[:] = base
    img += rng.normal(0, 4, (gh, gw, 1))              # 바닥 결
    tile = rng.uniform(18, 22)                        # 퍼즐 이음새 (가는 선)
    off = rng.uniform(0, tile, 2)
    for c in np.arange(off[0], GX, tile):
        cv2.line(img, (int(c / RES), 0), (int(c / RES), gh), (base * 0.75).tolist(), 1)
    for r in np.arange(off[1], GZ, tile):
        cv2.line(img, (0, int(r / RES)), (gw, int(r / RES)), (base * 0.75).tolist(), 1)
    width = rng.uniform(1.2, 2.6)                     # 테이프 폭 (cm)
    dark = rng.uniform(15, 60)
    p = np.stack([(pts[:, 0] + GX / 2) / RES, (GZ - pts[:, 1]) / RES], 1).astype(np.int32)
    cv2.polylines(img, [p], False, (dark, dark, dark), max(1, int(width / RES)), cv2.LINE_AA)
    only = np.zeros((gh, gw), np.uint8)
    cv2.polylines(only, [p], False, 255, max(1, int(width / RES)))
    return np.clip(img, 0, 255).astype(np.uint8), only


def render(rng):
    pts = line_points(rng)
    steer = steering_label(pts)
    if steer is None:
        return None, None
    mx, my = camera_map(rng)
    floor, only = floor_image(rng, pts)
    seen = cv2.remap(only, mx, my, cv2.INTER_NEAREST)[int(H * 0.4):]     # 모델이 보는 아래쪽 60%
    if (seen > 0).sum() < MIN_LINE_PIXELS:
        return None, None                                                # 선이 거의 안 보이는 장면은 빼기
    cam = cv2.remap(floor, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    # 조명: 밝기 · 한쪽이 밝은 그라데이션 · 가끔 반사 · 흐림 · 노이즈
    cam = cam.astype(np.float32) * rng.uniform(0.7, 1.15)
    if rng.random() < 0.5:                                               # 한쪽이 더 밝은 조명
        cam *= np.linspace(rng.uniform(0.85, 1.0), rng.uniform(0.85, 1.1), W)[None, :, None]
    if rng.random() < 0.25:
        spot = np.zeros((H, W), np.float32)
        cv2.ellipse(spot, (int(rng.uniform(0, W)), int(rng.uniform(H * 0.3, H))),
                    (int(rng.uniform(20, 60)), int(rng.uniform(10, 30))), rng.uniform(0, 180), 0, 360, 1, -1)
        cam += cv2.GaussianBlur(spot, (0, 0), 15)[..., None] * rng.uniform(30, 90)
    cam = cv2.GaussianBlur(cam, (0, 0), rng.uniform(0.4, 1.2))
    cam += rng.normal(0, rng.uniform(2, 6), cam.shape)
    return np.clip(cam, 0, 255).astype(np.uint8), steer


def to_class(s):
    return 0 if s < -EDGE else 2 if s > EDGE else 1


def make(n=3000, out="data", seed=0, balance=True):
    """n장을 만들어 out/synth_<n>/ 에 저장. balance=True면 왼쪽 · 직진 · 오른쪽을 비슷한 수로"""
    rng = np.random.default_rng(seed)
    folder = os.path.join(out, f"synth_{n}")
    os.makedirs(os.path.join(folder, "images"), exist_ok=True)
    quota = [math.ceil(n / 3)] * 3 if balance else [n] * 3
    have, rows = [0, 0, 0], []
    while len(rows) < n:
        img, s = render(rng)
        if img is None or have[to_class(s)] >= quota[to_class(s)]:
            continue
        have[to_class(s)] += 1
        name = f"images/{len(rows) + 1:06d}.jpg"
        cv2.imwrite(os.path.join(folder, name), img, [cv2.IMWRITE_JPEG_QUALITY, 90])
        left, right = 0.35 * (1 + s), 0.35 * (1 - s)
        m = max(abs(left), abs(right), 1.0)
        rows.append([name, f"{s:.3f}", "0.350", f"{len(rows) * 0.1:.3f}",
                     round(left / m * 255), round(right / m * 255), "synth", ""])
    with open(os.path.join(folder, "labels.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image", "steering", "throttle", "time", "left", "right", "mode", "step"])
        w.writerows(rows)
    with open(os.path.join(folder, "info.json"), "w", encoding="utf-8") as f:
        json.dump({"version": "v0", "rotate180": True, "steer_key": 0.5, "steer_key_shift": 1.0,
                   "num_classes": 3, "default_speed": 0.35, "label_source": "synthetic",
                   "synthetic": {"count": n, "seed": seed, "look_ahead_cm": LOOK_AHEAD, "gain": GAIN}},
                  f, ensure_ascii=False, indent=2)
    print(f"{folder}: {n}장 · 왼쪽 {have[0]} · 직진 {have[1]} · 오른쪽 {have[2]}")
    return folder


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else "data"
    if "--out" in sys.argv:
        args = [a for a in args if a != out]
    make(int(args[0]) if args else 3000, out)
