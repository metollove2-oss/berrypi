Colab 노트북 마지막 셀에서 받은 두 파일을 이 폴더에 넣으세요.
  line_model.onnx
  model_config.json
그다음  python3 dl_lab.py

아직 없으면 합성 데이터로 미리 학습해 둔 모델로 먼저 확인:
  python3 dl_lab.py --model models_synth/line_model.onnx
