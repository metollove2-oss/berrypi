/*
 * motor_serial.ino - Raspberry Pi의 시리얼 명령으로 바퀴 2개 제어 (L9110S 모터 드라이버, cv_lab · linecar 공용)
 */

const int L_IA = 3,  L_IB = 11;   // 왼쪽 바퀴  (L9110S A-IA, A-IB)
const int R_IA = 9,  R_IB = 10;   // 오른쪽 바퀴 (L9110S B-IA, B-IB)

const unsigned long TIMEOUT_MS = 500;   // 명령이 끊기면 정지할 시간
const int MIN_PWM = 125;                // 이보다 작으면 모터가 돌지 않음

const int LEFT_BOOST = 0;
const int RIGHT_BOOST = 0;             // 전진 시 오른쪽 모터 보정 (10부터 시작해 튜닝)

const int LEFT_DIR = 1;
const int RIGHT_DIR = 1;

char buf[32];
int len = 0;
unsigned long lastCmd = 0;
bool stopped = true;

void setMotor(int ia, int ib, int speed, int boost) {
  speed = constrain(speed, -255, 255);
  int pwm = abs(speed);

  // 전진(speed > 0)일 때만 boost 적용, 후진은 기존 MIN_PWM 유지
  int appliedBoost = (speed > 0) ? boost : 0;
  if (pwm > 0) {
    pwm = map(pwm, 1, 255, constrain(MIN_PWM + appliedBoost, 0, 255), 255);
  }

  if (speed > 0) {          // 전진
    analogWrite(ia, pwm);
    digitalWrite(ib, LOW);
  } else if (speed < 0) {   // 후진
    digitalWrite(ia, LOW);
    analogWrite(ib, pwm);
  } else {                  // 정지
    digitalWrite(ia, LOW);
    digitalWrite(ib, LOW);
  }
}

void drive(int left, int right) {
  setMotor(L_IA, L_IB, left * LEFT_DIR, LEFT_BOOST);
  setMotor(R_IA, R_IB, right * RIGHT_DIR, RIGHT_BOOST);
  stopped = (left == 0 && right == 0);
}

// 모터 테스트용: 변환 없이 PWM 값 그대로 두 바퀴 전진
void rawForward(int pwm) {
  pwm = constrain(pwm, 0, 255);
  digitalWrite(L_IB, LOW);  analogWrite(L_IA, pwm);
  digitalWrite(R_IB, LOW);  analogWrite(R_IA, pwm);
  stopped = (pwm == 0);
}

void handleLine(char *line) {
  int left, right, pwm;
  if (sscanf(line, "M,%d,%d", &left, &right) == 2) {
    drive(left, right);
    lastCmd = millis();
  } else if (sscanf(line, "P,%d", &pwm) == 1) {
    rawForward(pwm);
    lastCmd = millis();                 // 0.5초 뒤 자동 정지
    Serial.print("raw PWM ");
    Serial.println(pwm);
  } else if (strcmp(line, "PING") == 0) {
    Serial.println("PONG");
  }
}

void setup() {
  int pins[] = {L_IA, L_IB, R_IA, R_IB};
  for (int i = 0; i < 4; i++) pinMode(pins[i], OUTPUT);
  drive(0, 0);
  Serial.begin(115200);
  Serial.println("READY");
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n') {
      buf[len] = '\0';
      handleLine(buf);
      len = 0;
    } else if (c != '\r' && len < (int)sizeof(buf) - 1) {
      buf[len++] = c;
    }
  }

  if (!stopped && millis() - lastCmd > TIMEOUT_MS) {
    drive(0, 0);   // 명령이 끊김 → 자동 정지
  }
}
