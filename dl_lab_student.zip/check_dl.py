#!/usr/bin/env python3
"""
check_dl.py - dl_lab.py의 P1 ~ P3 자동 확인 (카메라 · 아두이노 없이)

  python3 check_dl.py                 # dl_lab.py 확인
  python3 check_dl.py dl_lab_B.py     # 나눠서 할 때: 자기 파일만

마지막에는 합성 사진을 새로 만들어 models_synth/의 모델로 실제 예측까지 해 봄 (P1 · P2를 모두 쓴 뒤)
[통과] 맞음 · [실패] 값이 틀림 · [오류] 실행 중 에러 · [아직] 아직 작성 안 함
"""
import importlib.util
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(HERE, sys.argv[1] if len(sys.argv) > 1 else "dl_lab.py")
spec = importlib.util.spec_from_file_location("lab", path)
lab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)
results = []


def check(name, fn, hint=""):
    try:
        fn()
        results.append(True)
        print(f"[통과] {name}")
    except NotImplementedError:
        results.append(False)
        print(f"[아직] {name}")
    except AssertionError as e:
        results.append(False)
        print(f"[실패] {name}: {e}" + (f"\n        힌트: {hint}" if hint else ""))
    except Exception as e:
        results.append(False)
        print(f"[오류] {name}: {type(e).__name__}: {e}")


# ---------------- P1 ----------------
rng = np.random.default_rng(0)
img = rng.integers(0, 255, (240, 320, 3), dtype=np.uint8)


def p1_shape():
    b = lab.to_blob(img, 0.4, (200, 66))
    assert isinstance(b, np.ndarray), f"numpy 배열이어야 함: {type(b)}"
    assert b.shape == (1, 3, 66, 200), f"모양이 (1, 3, 66, 200)이어야 함: {b.shape}"
    assert b.dtype == np.float32, f"float32여야 함: {b.dtype}"


def p1_values():
    b = lab.to_blob(img, 0.4, (200, 66))
    want = cv2.resize(img[96:], (200, 66), interpolation=cv2.INTER_AREA)
    assert b.max() > 1.5, "값은 0 ~ 255 그대로 (255로 나누지 않음, 모델 안에서 바꿈)"
    assert np.abs(b[0].transpose(1, 2, 0) - want).max() <= 1, "자르기 · 줄이기가 Colab D1과 다름 (위쪽 40%, INTER_AREA)"


def p1_order():
    one = np.zeros((240, 320, 3), np.uint8)
    one[:, :, 0] = 200                                   # 파란색(B)만
    b = lab.to_blob(one, 0.4, (200, 66))
    assert b[0, 0].mean() > 150 and b[0, 2].mean() < 50, "색 순서는 BGR 그대로 (transpose(2, 0, 1), RGB로 바꾸지 않음)"


def p1_crop():
    top = np.zeros((240, 320, 3), np.uint8)
    top[:96] = 255
    assert lab.to_blob(top, 0.4, (200, 66)).max() == 0, "위쪽 crop_top_ratio 비율을 잘라내지 않음"
    assert lab.to_blob(top, 0.3, (200, 66)).max() > 0, "crop_top_ratio 값을 써야 함 (0.4로 고정하지 말 것)"


check("P1 to_blob: 모양 (1, 3, 66, 200) · float32", p1_shape, "[np.newaxis], .astype(np.float32)")
check("P1 to_blob: 자르기 · 줄이기 · 값 범위", p1_values)
check("P1 to_blob: 색 순서 (BGR)", p1_order, "transpose(2, 0, 1)")
check("P1 to_blob: crop_top_ratio 사용", p1_crop)

# ---------------- P2 ----------------
CS = [-0.55, 0.0, 0.55]


def p2():
    for probs, want in [([0.1, 0.2, 0.7], (0.55, 2, 0.7)), ([0.6, 0.3, 0.1], (-0.55, 0, 0.6)),
                        ([0.2, 0.5, 0.3], (0.0, 1, 0.5))]:
        got = lab.choose_steering(np.array(probs, np.float32), CS)
        assert len(got) == 3, f"(조향, 단계, 확률) 3개를 반환: {got}"
        assert abs(got[0] - want[0]) < 1e-6 and got[1] == want[1] and abs(got[2] - want[2]) < 1e-6, \
            f"choose_steering({probs}) = {got}, 정답 {want}"
    got = lab.choose_steering(np.array([0.1, 0.2, 0.7], np.float32), CS)
    assert type(got[1]) is int and type(got[0]) is float and type(got[2]) is float, \
        f"int · float로 반환 (numpy 값 그대로면 화면 · json에서 문제): {[type(v).__name__ for v in got]}"


check("P2 choose_steering", p2, "i = int(np.argmax(probs)) → float(class_steering[i]), i, float(probs[i])")

# ---------------- P3 ----------------


def p3_seen():
    assert lab.hybrid(0.3, 150.0, 4, -0.2) == (0.3, 0, 0.3, "model"), \
        f"선이 보이면 (모델 조향, 0, 모델 조향, 'model'): {lab.hybrid(0.3, 150.0, 4, -0.2)}"


def p3_sequence():
    steer, lost, last, mode = lab.hybrid(0.5, 160.0, 0, None)
    seq = []
    for _ in range(lab.LOST_STOP + 1):
        steer, lost, last, mode = lab.hybrid(-0.9, None, lost, last)      # 선 없음: 모델 값(-0.9)은 쓰면 안 됨
        seq.append((steer, lost, mode))
    want = [(0.5, k, "hold") for k in range(1, lab.LOST_STOP)] + [(None, lab.LOST_STOP, "stop"), (None, lab.LOST_STOP + 1, "stop")]
    assert seq == want, f"선을 계속 놓칠 때\n          결과 {seq}\n          정답 {want}"
    assert lab.hybrid(0.2, 100.0, lost, last)[:2] == (0.2, 0), "다시 선을 찾으면 lost = 0, 모델 조향"


def p3_first():
    assert lab.hybrid(0.4, None, 0, None) == (None, 1, None, "stop"), \
        f"처음부터 선이 없으면 (기억한 조향 없음) 바로 정지: {lab.hybrid(0.4, None, 0, None)}"


check("P3 hybrid: 선이 보이면 모델", p3_seen)
check("P3 hybrid: 놓치면 HOLD → LOST_STOP에서 정지", p3_sequence, "lost += 1 한 뒤 lost < LOST_STOP 이면 hold")
check("P3 hybrid: 기억한 조향이 없으면 정지", p3_first)

# ---------------- 합쳐서: 합성 사진으로 진짜 모델 실행 ----------------


def together():
    model = os.path.join(HERE, "models_synth", "line_model.onnx")
    if not os.path.isfile(model):
        print("        (models_synth/line_model.onnx 없음 → 건너뜀)")
        return
    import make_synth
    net, cfg = lab.load_model(model)
    r = np.random.default_rng(123)
    right = total = 0
    while total < 60:
        im, s = make_synth.render(r)
        if im is None:
            continue
        probs = lab.run_model(net, lab.to_blob(im, cfg["crop_top_ratio"], (cfg["input_width"], cfg["input_height"])))
        _, idx, _ = lab.choose_steering(probs, cfg["class_steering"])
        right += idx == make_synth.to_class(s)
        total += 1
    print(f"        합성 사진 {total}장: 모델이 맞힌 단계 {right}장 ({right / total:.0%})")
    assert right / total >= 0.7, "70% 이상이어야 함 → P1 전처리(자르기 · 크기 · 색 순서)가 Colab과 같은지 확인"


sys.path.insert(0, HERE)
check("합쳐서: 합성 사진 → P1 → 모델 → P2", together)

n = sum(results)
print(f"\n결과: 통과 {n} / {len(results)}")
if n == len(results):
    print("모두 통과! 바퀴를 띄우고  python3 dl_lab.py --model models_synth/line_model.onnx  로 화면을 확인하세요.")
