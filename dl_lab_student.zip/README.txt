딥러닝 선 따라가기 짝 프로그래밍 실습 (dl_lab, 1차시)
=====================================================

파일
  dl_lab_train.ipynb   Colab 노트북. [D1] ~ [D4] 빈칸 작성 → 학습 → line_model.onnx + model_config.json
  dl_lab.py            Pi 실습 코드. [P1] ~ [P3] 빈칸 작성 → 학습한 모델로 주행 (OpenCV 선 확인과 함께 = 하이브리드)
  check_dl.py          카메라 · 아두이노 없이 P1 ~ P3 자동 확인 (마지막에 합성 사진으로 모델 실행까지)
  make_synth.py        합성 데이터 만들기 (노트북 안에도 같은 코드가 있음)
  models_synth/        합성 데이터 3,000장으로 미리 학습해 둔 모델 (흐름 확인용)
  models/              Colab에서 받은 내 모델을 넣는 곳
  arduino/motor_serial/motor_serial.ino   아두이노 코드 (cv_lab과 같음)

분담 (cv_lab과 같은 방식)
  A: Colab 노트북 D1 ~ D4 → 학습 → 모델 두 파일 받기
  B: Pi dl_lab.py P1 ~ P3 → check_dl.py 모두 통과 → 합성 모델로 화면 확인
  합치기: A가 Colab에서 받은 두 파일(line_model.onnx, model_config.json)을 B의 Pi dl_lab/models/ 에 넣고
          바퀴를 띄운 채 확인 → 트랙
  D1과 P1은 같은 전처리입니다. 둘이 같은 숫자(자르는 비율 0.4, 200 × 66, INTER_AREA)를 쓰는지 서로 확인하세요.

준비 (Pi 5, 한 번만) - cv_lab에서 이미 했다면 dl_lab 폴더에 venv만 새로 만들기
  sudo apt install -y python3-venv python3-picamera2 python3-opencv python3-numpy python3-flask python3-serial
  mkdir -p ~/codes/dl_lab && cd ~/codes/dl_lab && unzip ~/Downloads/dl_lab_student.zip
  python3 -m venv --system-site-packages venv
  source venv/bin/activate                      (새 터미널마다)
  아두이노: arduino/motor_serial/motor_serial.ino (cv_lab에서 올렸으면 그대로)
  모델 실행은 OpenCV(cv2.dnn)로 함 → PyTorch · onnxruntime 설치 필요 없음

Colab (A)
  1) colab.research.google.com → 파일 → 노트 업로드 → dl_lab_train.ipynb
  2) 런타임 → 런타임 유형 변경 → T4 GPU
  3) 1번 셀에서 데이터 고르기 (둘 중 하나)
       DATA_OPTION = 'zip'       zip 올리기: 선생님이 준 synth_3000.zip 또는 내 데이터 (label_edit.py 내보내기)
                                 ZIP_FROM = 'upload' (내 컴퓨터) 또는 'drive' (Google Drive에 미리 올려 두면 가장 빠름)
       DATA_OPTION = 'generate'  zip이 없을 때: Colab에서 합성 데이터 3,000장 만들기 (약 1분, 인터넷 거의 안 씀)
     그다음 위에서부터 차례로 실행
  4) D1 ~ D4 작성 → 각 빈칸 아래 확인 셀에서 [통과]
  5) 학습 (GPU 1 ~ 2분) → 혼동 행렬 확인 → 마지막 셀에서 두 파일 받기

Pi (B)
  0) cd ~/codes/dl_lab && source venv/bin/activate
  1) python3 check_dl.py                       9개 모두 [통과]가 목표
     python3 check_dl.py dl_lab_B.py          (나눠서 할 때: 자기 파일만)
  2) 차를 책 위에 올려 바퀴를 띄움
     python3 dl_lab.py --model models_synth/line_model.onnx   → http://<Pi IP>:8000
     (--model = 쓸 모델 파일 지정. 여기서는 미리 학습해 둔 합성 모델)
     화면 아래 막대 = 모델의 단계별 확률, 위쪽 글자 MODEL / HOLD / STOP
  3) A의 모델로 바꾸기: A가 Colab 마지막 셀에서 받은 두 파일
       line_model.onnx      (학습한 모델)
       model_config.json    (단계 이름 · 단계별 조향값 · 전처리 설정)
     을 dl_lab/models/ 에 넣고 --model 없이 실행 → models/ 의 모델을 읽음
     python3 dl_lab.py                                       → http://<Pi IP>:8000
  4) 트랙 위에서 '출발' (Space). speed는 0.25 ~ 0.3부터

합성 데이터와 진짜 데이터
  - 합성 데이터는 흐름 확인용입니다. 진짜 트랙에서 잘 달리는 모델은 직접 모은 데이터로 학습해야 합니다.
  - 진짜 데이터: linecar의 collect.py(한 걸음씩 모드) 또는 cv_lab 녹화 → label_edit.py로 정리 → 내보내기 zip
    → 노트북 1번 셀 DATA_OPTION = 'zip'으로 올리기. 이미 합성 데이터를 만들었다면  !rm -rf /content/data/synth_*
  - cv_lab 녹화 폴더에도 이제 info.json이 생깁니다 (없으면 노트북이 사진을 180도 돌려서 학습함)

잘 안 될 때
  - "모델 파일이 없음": models/ 에 두 파일을 넣었는지, 또는 --model models_synth/line_model.onnx
  - "모델 입력 오류": P1의 결과가 (1, 3, 66, 200) float32인지 (check_dl.py)
  - 화면에서 확률은 맞는데 반대로 꺾음: model_config.json의 class_steering 순서(왼쪽, 직진, 오른쪽)와 부호
  - 계속 STOP: 선 확인(C1 · C2) 문제 → thresh · roi_top · look 슬라이더 (mask에 선이 하얗게 보이게)
  - ModuleNotFoundError: venv를 켰는지 (source venv/bin/activate)
  - Permission denied: '/dev/ttyACM0' 일 때만: sudo usermod -aG dialout $USER → 다시 로그인
